extends "res://scripts/s_base.gd"
## Layar loading: analisis lagu (thread latar) dengan progress.

var _title: Label
var _stage: Label
var _bar: ProgressBar
var _hint: Label


func _ready() -> void:
	set_bg_alpha(0.97)
	var col := UI.vbox(16)
	col.alignment = BoxContainer.ALIGNMENT_CENTER
	mc.add_child(col)
	_title = UI.label("Loading...", 40, UI.TX, HORIZONTAL_ALIGNMENT_CENTER)
	col.add_child(_title)
	_stage = UI.label("", 24, UI.MUT, HORIZONTAL_ALIGNMENT_CENTER)
	col.add_child(_stage)
	var c := CenterContainer.new()
	_bar = ProgressBar.new()
	_bar.custom_minimum_size = Vector2(640, 22)
	_bar.max_value = 1.0
	_bar.step = 0.001
	_bar.show_percentage = false
	c.add_child(_bar)
	col.add_child(c)
	_hint = UI.label("", 19, Color(1, 1, 1, 0.4), HORIZONTAL_ALIGNMENT_CENTER)
	col.add_child(_hint)


func on_enter(args: Dictionary = {}) -> void:
	_title.text = String(args.get("title", "Loading..."))
	_stage.text = String(args.get("stage", ""))
	_hint.text = String(args.get("hint", ""))
	_bar.value = float(args.get("p", 0.0))


func set_progress(p: float, stage_text: String) -> void:
	_bar.value = p
	_stage.text = stage_text


func on_back() -> void:
	pass
