extends Node
## Titik masuk BeatDrop: membangun scene lewat kode, menghubungkan layar, input sentuh, file manager,
## analisis lagu (thread), dan siklus hidup Android.

const C = preload("res://scripts/consts.gd")
const UI = preload("res://scripts/ui.gd")
const Analyzer = preload("res://scripts/analyzer.gd")
const GameScript = preload("res://scripts/game.gd")
const Layers = preload("res://scripts/layers.gd")
const HudScript = preload("res://scripts/hud.gd")
const SCREEN_SCRIPTS := {
	"intro": preload("res://scripts/s_intro.gd"),
	"menu": preload("res://scripts/s_menu.gd"),
	"lib": preload("res://scripts/s_lib.gd"),
	"detail": preload("res://scripts/s_detail.gd"),
	"ach": preload("res://scripts/s_ach.gd"),
	"settings": preload("res://scripts/s_settings.gd"),
	"loading": preload("res://scripts/s_loading.gd"),
	"pause": preload("res://scripts/s_pause.gd"),
	"result": preload("res://scripts/s_result.gd"),
}
const MENU_SCREENS := ["menu", "lib", "ach", "settings"]
const STAGE_BASE := [0.0, 0.0, 0.2, 0.2, 0.2, 0.75, 0.95]
const STAGE_W := [0.0, 0.2, 0.7, 0.7, 0.55, 0.2, 0.05]
const KEY_LANES := {KEY_D: 0, KEY_F: 1, KEY_SPACE: 2, KEY_J: 3, KEY_K: 4}

var ui_root: Control
var bg_tex: TextureRect
var decor: Control
var gtex: TextureRect
var hud
var gv: SubViewport
var groot: Node2D
var game
var screens := {}
var cur_screen := ""
var lw := 1280.0
var lh := 720.0
var _hs := 1.8
var _toast_panel: PanelContainer
var _toast_label: Label
var _toast_tw: Tween = null
var _toast_queue: Array = []

var an = null
var cur_song_id := ""
var cur_song_name := ""
var cur_stream: AudioStream = null
var cur_notes: Array = []
var cur_gen_used := 1
var sel_diff := 1
var _after_analysis := "detail"
var _touch_lane := {}
var _preview: AudioStreamPlayer
var _preview_pos := 0.0
var _back_t := 0
var _fd: FileDialog = null
var _mobile := OS.has_feature("mobile")


func _ready() -> void:
	get_tree().set_auto_accept_quit(false)
	Engine.max_fps = C.FPS_CAP
	process_mode = Node.PROCESS_MODE_ALWAYS
	_build_scene()
	get_viewport().size_changed.connect(_on_resize)
	_on_resize()
	set_process(false)
	_goto("intro")


# ------------------------------------------------------------------ scene

func _build_scene() -> void:
	ui_root = Control.new()
	ui_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	ui_root.theme = UI.theme()
	ui_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(ui_root)

	# latar menu (gradien) + not melayang
	var g := Gradient.new()
	g.offsets = PackedFloat32Array([0.0, 1.0])
	g.colors = PackedColorArray([Color("#0d0a26"), Color("#1c0b30")])
	var gt := GradientTexture2D.new()
	gt.gradient = g
	gt.fill_from = Vector2(0, 0)
	gt.fill_to = Vector2(0, 1)
	gt.width = 8
	gt.height = 128
	bg_tex = TextureRect.new()
	bg_tex.texture = gt
	bg_tex.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	bg_tex.stretch_mode = TextureRect.STRETCH_SCALE
	bg_tex.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg_tex.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui_root.add_child(bg_tex)
	decor = Control.new()
	decor.set_anchors_preset(Control.PRESET_FULL_RECT)
	decor.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui_root.add_child(decor)
	_build_decor()

	# game: SubViewport beresolusi tetap (HD), ditampilkan lewat TextureRect
	gv = SubViewport.new()
	gv.disable_3d = true
	gv.transparent_bg = false
	gv.msaa_2d = Viewport.MSAA_DISABLED
	gv.render_target_update_mode = SubViewport.UPDATE_DISABLED
	gv.size = Vector2i(1280, 720)
	add_child(gv)
	groot = Node2D.new()
	gv.add_child(groot)
	game = GameScript.new()
	add_child(game)
	var mk := func(mode: int) -> Node2D:
		var l := Layers.new()
		l.g = game
		l.mode = mode
		groot.add_child(l)
		return l
	var l_bg: Node2D = mk.call(0)
	var l_glow: Node2D = mk.call(4)
	var l_lane: Node2D = mk.call(1)
	var l_dyn: Node2D = mk.call(2)
	var l_fluid: Node2D = mk.call(3)
	game.layers_static = [l_bg, l_glow, l_lane]
	game.layers_dyn = [l_dyn, l_fluid]
	gtex = TextureRect.new()
	gtex.texture = gv.get_texture()
	gtex.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	gtex.stretch_mode = TextureRect.STRETCH_SCALE
	gtex.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	gtex.set_anchors_preset(Control.PRESET_FULL_RECT)
	gtex.mouse_filter = Control.MOUSE_FILTER_IGNORE
	gtex.visible = false
	ui_root.add_child(gtex)
	hud = HudScript.new()
	hud.g = game
	ui_root.add_child(hud)
	game.layers_dyn.append(hud)
	hud.pause_pressed.connect(func(): game.pause_game())

	for k in SCREEN_SCRIPTS:
		var s = SCREEN_SCRIPTS[k].new()
		s.nav.connect(_on_nav)
		s.toast_req.connect(_toast)
		ui_root.add_child(s)
		screens[k] = s
	screens["settings"].changed.connect(_on_settings_changed)

	_preview = AudioStreamPlayer.new()
	_preview.bus = Sfx.music_bus_name
	_preview.finished.connect(func():
		if cur_screen == "detail" and _preview.stream != null:
			_preview.play(_preview_pos))
	add_child(_preview)

	_toast_panel = UI.panel(Color(0.059, 0.047, 0.14, 0.92), Color(1, 1, 1, 0.2), 999, 16)
	_toast_label = UI.label("", 22, UI.TX, HORIZONTAL_ALIGNMENT_CENTER)
	_toast_panel.add_child(_toast_label)
	_toast_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_toast_panel.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	_toast_panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_toast_panel.grow_vertical = Control.GROW_DIRECTION_BEGIN
	_toast_panel.offset_bottom = -36
	_toast_panel.visible = false
	ui_root.add_child(_toast_panel)

	game.finished.connect(_on_game_finished)
	game.toast.connect(_toast)
	game.state_changed.connect(_on_game_state)
	game.quality_changed.connect(func(_q: float): _apply_render_size())


func _build_decor() -> void:
	var vw := get_viewport().get_visible_rect().size.x
	for i in 9:
		var sz := randi_range(40, 90)
		var ic := UI.icon_rect("note", sz, Color(1, 1, 1, 0.06))
		decor.add_child(ic)
		var x := randf_range(0.04, 0.96) * vw
		ic.position = Vector2(x, 780.0)
		var tw := create_tween()
		tw.set_loops()
		var dur := randf_range(16.0, 30.0)
		tw.tween_interval(randf() * 8.0)
		tw.tween_property(ic, "position:y", -120.0, dur).from(800.0)


# ------------------------------------------------------------------ ukuran / area aman

func _on_resize() -> void:
	var vs := get_viewport().get_visible_rect().size
	if vs.x < 100.0 or vs.y < 100.0:
		return
	lw = vs.x
	lh = vs.y
	_relayout()


func _insets() -> Vector4:
	var os_name := OS.get_name()
	if os_name != "Android" and os_name != "iOS":
		return Vector4.ZERO
	var sa := DisplayServer.get_display_safe_area()
	var scr := DisplayServer.screen_get_size()
	var win := DisplayServer.window_get_size()
	if scr.x <= 0 or scr.y <= 0 or win.x <= 0:
		return Vector4.ZERO
	var f := lw / float(win.x)
	var l := clampf(float(sa.position.x), 0.0, 220.0) * f
	var t := clampf(float(sa.position.y), 0.0, 220.0) * f
	var r := clampf(float(scr.x - sa.end.x), 0.0, 220.0) * f
	var b := clampf(float(scr.y - sa.end.y), 0.0, 220.0) * f
	return Vector4(l, t, r, b)


func _relayout() -> void:
	_hs = lh / C.GAME_H
	var ins := _insets()
	for k in screens:
		screens[k].set_insets(ins.x, ins.y, ins.z, ins.w)
	hud.set_insets(ins.z, ins.y)
	_apply_render_size()
	var vw := lw / _hs
	game.layout(vw, C.GAME_H, ins.w / _hs, ins.y / _hs, _render_k())


func _render_k() -> float:
	var rh: float = float(C.RES_H[int(Store.SET["res"])]) * float(game.Q)
	rh = minf(rh, float(DisplayServer.window_get_size().y))
	rh = maxf(rh, 360.0)
	return rh / C.GAME_H


func _apply_render_size() -> void:
	var k := _render_k()
	var vw := lw / _hs
	gv.size = Vector2i(maxi(2, roundi(vw * k)), maxi(2, roundi(C.GAME_H * k)))
	groot.scale = Vector2(k, k)


func _on_settings_changed() -> void:
	_relayout()


# ------------------------------------------------------------------ navigasi

func _hide_screens() -> void:
	for k in screens:
		screens[k].visible = false
	cur_screen = ""


func _game_live(on: bool) -> void:
	gv.render_target_update_mode = SubViewport.UPDATE_ALWAYS if on else SubViewport.UPDATE_DISABLED


func _set_game_visible(on: bool) -> void:
	gtex.visible = on
	hud.visible = on
	bg_tex.visible = not on
	decor.visible = not on
	_game_live(on)


func _goto(target: String, args: Dictionary = {}) -> void:
	var was := cur_screen
	if target in MENU_SCREENS or target == "intro" or target == "detail" or target == "loading":
		if game.state != "idle":
			game.to_idle()
		_set_game_visible(false)
	for k in screens:
		screens[k].visible = (k == target)
	cur_screen = target
	if target in MENU_SCREENS:
		_stop_preview()
		Sfx.bgm_start()
	elif target == "detail":
		Sfx.bgm_stop()
	screens[target].on_enter(args)
	if target == "detail":
		_start_preview()
	elif target == "pause" or target == "result":
		await get_tree().create_timer(0.2).timeout
		if cur_screen == target:
			_game_live(false)
	if was == "pause" and target != "pause":
		_game_live(game.state != "idle")


func _on_nav(target: String, args: Dictionary) -> void:
	match target:
		"menu", "lib", "ach", "settings":
			_goto(target, args)
		"pick":
			_pick_files()
		"open_song":
			_open_song(String(args["id"]))
		"start":
			_start_game(int(args["diff"]))
		"resume":
			_game_live(true)
			_hide_screens()
			game.resume_game()
		"retry":
			game.to_idle()
			_start_game(sel_diff)
		"quit":
			var now := Time.get_ticks_msec()
			if now - _back_t < 2200:
				Store.save_now()
				get_tree().quit()
			else:
				_back_t = now
				_toast("Press back again to exit")


func _on_back() -> void:
	if game.state == "play":
		game.pause_game()
		return
	if cur_screen == "":
		return
	screens[cur_screen].on_back()


# ------------------------------------------------------------------ toast

func _toast(msg: String) -> void:
	_toast_label.text = msg
	_toast_panel.visible = true
	_toast_panel.modulate.a = 1.0
	if _toast_tw != null:
		_toast_tw.kill()
	_toast_tw = create_tween()
	_toast_tw.tween_interval(2.6)
	_toast_tw.tween_property(_toast_panel, "modulate:a", 0.0, 0.4)
	_toast_tw.tween_callback(func(): _toast_panel.visible = false)


func _show_achievements(added: Array) -> void:
	if added.is_empty():
		return
	Sfx.play("unlock")
	for a in added:
		_toast_queue.append("Achievement: " + String(a[0]))
	_drain_toasts()


func _drain_toasts() -> void:
	if _toast_queue.is_empty():
		return
	var m: String = _toast_queue.pop_front()
	_toast(m)
	if not _toast_queue.is_empty():
		await get_tree().create_timer(1.4).timeout
		_drain_toasts()


# ------------------------------------------------------------------ file manager

func _pick_files() -> void:
	var android := OS.get_name() == "Android"
	if DisplayServer.has_feature(DisplayServer.FEATURE_NATIVE_DIALOG_FILE):
		var filters := PackedStringArray(["audio/*"]) if android else PackedStringArray(["*.mp3, *.ogg ; Audio files"])
		var err := DisplayServer.file_dialog_show("Select songs", "", "", false,
				DisplayServer.FILE_DIALOG_MODE_OPEN_FILES, filters, _on_dialog_result)
		if err == OK:
			return
	# cadangan: dialog bawaan Godot
	if android:
		OS.request_permissions()
	if _fd == null:
		_fd = FileDialog.new()
		_fd.access = FileDialog.ACCESS_FILESYSTEM
		_fd.file_mode = FileDialog.FILE_MODE_OPEN_FILES
		_fd.use_native_dialog = false
		_fd.title = "Select songs (MP3 / OGG)"
		_fd.filters = PackedStringArray(["*.mp3, *.ogg ; Audio files"])
		_fd.files_selected.connect(func(paths: PackedStringArray): _add_songs(paths))
		ui_root.add_child(_fd)
	var start_dir := OS.get_system_dir(OS.SYSTEM_DIR_MUSIC)
	if start_dir != "":
		_fd.current_dir = start_dir
	_fd.popup_centered_ratio(0.85)


func _on_dialog_result(status: bool, paths: PackedStringArray, _filter_index: int) -> void:
	if status and paths.size() > 0:
		call_deferred("_add_songs", paths)


func _add_songs(paths: PackedStringArray) -> void:
	_goto("loading", {"title": "Importing songs...", "stage": "", "hint": "Songs are copied into the game storage, so they work offline."})
	var ok := 0
	var last_msg := ""
	for i in paths.size():
		screens["loading"].set_progress(float(i) / float(paths.size()), "Reading file %d of %d..." % [i + 1, paths.size()])
		await get_tree().process_frame
		await get_tree().process_frame
		var r := Store.add_song(paths[i])
		if r["ok"]:
			ok += 1
		else:
			last_msg = String(r["msg"])
	var added := Store.check_achv()
	_goto("lib")
	if ok > 0:
		_toast("%d song%s added" % [ok, "" if ok == 1 else "s"])
		_show_achievements(added)
	else:
		_toast(last_msg if last_msg != "" else "No song added")


# ------------------------------------------------------------------ analisis lagu

func _open_song(id: String) -> void:
	var e := Store.find_song(id)
	if e.is_empty():
		return
	var stream := Store.load_song_stream(id)
	if stream == null or stream.get_length() <= 0.0:
		_toast("Could not load this song file")
		return
	cur_song_id = id
	cur_song_name = String(e["name"])
	cur_stream = stream
	_after_analysis = "detail"
	_begin_analysis()


func _begin_analysis() -> void:
	Sfx.bgm_stop()
	_stop_preview()
	an = Analyzer.new()
	var gen := int(Store.SET["gen"])
	an.start(cur_stream, cur_song_id, gen, Store.SET.duplicate())
	var hint := "First time only - results are saved in the cache for next time."
	if gen == 3:
		hint = "Melody analysis is the slowest. First time only - results are cached."
	_goto("loading", {"title": "Analyzing " + cur_song_name, "stage": "Starting...", "hint": hint, "p": 0.0})
	set_process(true)


func _process(_delta: float) -> void:
	if an == null:
		set_process(false)
		return
	var st := clampi(int(an.stage), 0, 6)
	var p := float(STAGE_BASE[st]) + float(STAGE_W[st]) * float(an.progress())
	screens["loading"].set_progress(clampf(p, 0.0, 1.0), String(an.stage_text()))
	if an.finished:
		an.join()
		var res: Array = an.result
		var used := int(an.used_gen)
		an = null
		set_process(false)
		_on_analysis_done(res, used)


func _on_analysis_done(res: Array, used: int) -> void:
	var total := 0
	for a in res:
		total += a.size()
	if total == 0:
		_toast("No notes could be detected in this song.")
		_goto("lib")
		return
	cur_notes = res
	cur_gen_used = used
	if used != int(Store.SET["gen"]):
		_toast("Selected generator failed, used V1 instead.")
	if _after_analysis == "game":
		_launch_game(sel_diff)
	else:
		var counts: Array = []
		for a in res:
			counts.append(a.size())
		_goto("detail", {"id": cur_song_id, "counts": counts, "gen": used, "diff": sel_diff})


# ------------------------------------------------------------------ preview lagu

func _start_preview() -> void:
	if cur_stream == null:
		return
	_preview.stream = cur_stream
	_preview_pos = cur_stream.get_length() * 0.3
	_preview.volume_db = -40.0
	_preview.play(_preview_pos)
	var tw := create_tween()
	tw.tween_property(_preview, "volume_db", -8.0, 1.2)
	Store.stats["previews"] += 1
	var added := Store.check_achv()
	_show_achievements(added)


func _stop_preview() -> void:
	if _preview != null:
		_preview.stop()


# ------------------------------------------------------------------ mulai game

func _start_game(diff: int) -> void:
	sel_diff = diff
	if cur_notes.is_empty() or cur_stream == null:
		_toast("Song not ready")
		return
	Sfx.click()
	_launch_game(diff)


func _launch_game(diff: int) -> void:
	Sfx.bgm_stop()
	_stop_preview()
	_hide_screens()
	_relayout()
	_touch_lane.clear()
	_set_game_visible(true)
	var notes: Array = cur_notes[clampi(diff, 0, 2)]
	game.start_song(cur_song_id, cur_song_name, cur_stream, notes, diff, cur_gen_used)


func _on_game_state(s: String) -> void:
	if s == "pause":
		_touch_lane.clear()
		for l in 5:
			game.down[l] = 0
		_goto("pause")


func _on_game_finished(failed: bool, run: Dictionary) -> void:
	_touch_lane.clear()
	var nw := Store.best_try(String(run["id"]), int(run["diff"]), int(run["score"]))
	Store.record_run(run)
	var added := Store.check_achv(run)
	_goto("result", {"run": run, "new_best": nw})
	_show_achievements(added)


# ------------------------------------------------------------------ input

func _input(e: InputEvent) -> void:
	if game == null:
		return
	if game.state == "play" or game.state == "count":
		if e is InputEventScreenTouch:
			_pointer(e.index, e.pressed, e.position)
		elif e is InputEventMouseButton and not _mobile and e.button_index == MOUSE_BUTTON_LEFT:
			_pointer(-1, e.pressed, e.position)      # uji coba di PC
		elif e is InputEventKey and not e.echo:
			if e.physical_keycode == KEY_ESCAPE and e.pressed and game.state == "play":
				game.pause_game()
			elif KEY_LANES.has(e.physical_keycode):
				var kl: int = KEY_LANES[e.physical_keycode]
				if e.pressed:
					game.press(kl)
				else:
					game.release(kl)
	elif e is InputEventKey and e.pressed and not e.echo and e.physical_keycode == KEY_ESCAPE:
		_on_back()


func _pointer(idx: int, pressed: bool, pos: Vector2) -> void:
	if pressed:
		if hud.pause_btn.get_global_rect().has_point(pos):
			return
		var v := pos / _hs
		var l: int = game.lane_at(v.x, v.y)
		if l >= 0:
			_touch_lane[idx] = l
			game.press(l)
			get_viewport().set_input_as_handled()
	elif _touch_lane.has(idx):
		var l2: int = _touch_lane[idx]
		_touch_lane.erase(idx)
		game.release(l2)
		get_viewport().set_input_as_handled()


# ------------------------------------------------------------------ siklus hidup (Android)

func _notification(what: int) -> void:
	match what:
		NOTIFICATION_WM_GO_BACK_REQUEST:
			_on_back()
		NOTIFICATION_APPLICATION_PAUSED, NOTIFICATION_WM_WINDOW_FOCUS_OUT:
			if game != null and game.state == "play":
				game.pause_game()
			if Sfx.bgm != null:
				Sfx.bgm.stream_paused = true
			if _preview != null:
				_preview.stream_paused = true
			Store.save_now()
		NOTIFICATION_APPLICATION_RESUMED, NOTIFICATION_WM_WINDOW_FOCUS_IN:
			if Sfx.bgm != null:
				Sfx.bgm.stream_paused = false
			if _preview != null:
				_preview.stream_paused = false
			Sfx.bgm_resume_if_wanted()
		NOTIFICATION_WM_CLOSE_REQUEST:
			Store.save_now()
			get_tree().quit()
