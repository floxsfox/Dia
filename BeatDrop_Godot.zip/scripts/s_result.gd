extends "res://scripts/s_base.gd"
## Layar hasil.

const C = preload("res://scripts/consts.gd")

var _rank: Label
var _title: Label
var _score: Label
var _note: Label
var _hp: Label
var _grid: HBoxContainer


func _ready() -> void:
	set_bg_alpha(0.88)
	var col := UI.vbox(10)
	col.alignment = BoxContainer.ALIGNMENT_CENTER
	mc.add_child(col)
	_title = UI.label("", 26, UI.MUT, HORIZONTAL_ALIGNMENT_CENTER)
	col.add_child(_title)
	_rank = UI.label("S", 170, UI.PINK, HORIZONTAL_ALIGNMENT_CENTER)
	col.add_child(_rank)
	_score = UI.label("0", 64, UI.TX, HORIZONTAL_ALIGNMENT_CENTER)
	col.add_child(_score)
	_hp = UI.label("", 20, UI.MUT, HORIZONTAL_ALIGNMENT_CENTER)
	col.add_child(_hp)
	_note = UI.label("", 22, UI.GOLD, HORIZONTAL_ALIGNMENT_CENTER)
	col.add_child(_note)
	_grid = UI.hbox(30)
	_grid.alignment = BoxContainer.ALIGNMENT_CENTER
	col.add_child(_grid)
	col.add_child(UI.spacer(10))
	var br := UI.hbox(14)
	br.alignment = BoxContainer.ALIGNMENT_CENTER
	var again := UI.primary_button("Play again", 28, Vector2(300, 72))
	again.pressed.connect(func():
		Sfx.click()
		nav.emit("retry", {}))
	br.add_child(again)
	var songs := UI.button("Songs", 26, Vector2(200, 72))
	songs.pressed.connect(func():
		Sfx.click()
		nav.emit("lib", {}))
	br.add_child(songs)
	var mn := UI.button("Menu", 26, Vector2(200, 72))
	mn.pressed.connect(func():
		Sfx.click()
		nav.emit("menu", {}))
	br.add_child(mn)
	col.add_child(br)


func on_enter(a: Dictionary = {}) -> void:
	var run: Dictionary = a.get("run", {})
	var g: String = String(run.get("grade", "F"))
	var failed: bool = bool(run.get("failed", false))
	_title.text = "%s  -  %s%s" % [String(run.get("name", "")), C.DIFF_N[int(run.get("diff", 0))], "  -  FAILED" if failed else ""]
	_rank.text = g
	_rank.add_theme_color_override("font_color", C.grade_color(g))
	_rank.pivot_offset = _rank.size / 2.0
	_rank.scale = Vector2(2.4, 2.4)
	_rank.modulate.a = 0.0
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(_rank, "scale", Vector2.ONE, 0.45).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(_rank, "modulate:a", 1.0, 0.25)
	var sc := int(run.get("score", 0))
	var tw2 := create_tween()
	tw2.tween_method(func(v: float): _score.text = C.fmt_int(int(v)), 0.0, float(sc), 1.1).set_trans(Tween.TRANS_QUART).set_ease(Tween.EASE_OUT)
	_hp.text = "HP %d%%" % roundi(float(run.get("hp", 0.0)))
	_note.text = ("New best!  " if bool(a.get("new_best", false)) else "") + "Accuracy %.1f%%  -  Max combo %d" % [float(run.get("acc", 0.0)) * 100.0, int(run.get("maxC", 0))]
	UI.clear_children(_grid)
	var cnt: Array = run.get("cnt", [0, 0, 0, 0])
	var names := ["Perfect", "Great", "Good", "Miss"]
	var idx := [2, 1, 0, 3]
	for i in 4:
		var v := UI.vbox(0)
		v.add_child(UI.label(str(int(cnt[idx[i]])), 38, UI.TX, HORIZONTAL_ALIGNMENT_CENTER))
		v.add_child(UI.label(names[i], 19, UI.MUT, HORIZONTAL_ALIGNMENT_CENTER))
		_grid.add_child(v)
	if not failed:
		Sfx.play("fanfare")


func on_back() -> void:
	nav.emit("menu", {})
