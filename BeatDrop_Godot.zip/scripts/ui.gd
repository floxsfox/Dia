extends RefCounted
## Helper UI: warna, tema global, pembuat widget kecil.

const WSlider = preload("res://scripts/w_slider.gd")
const WSwitch = preload("res://scripts/w_switch.gd")
const WTap = preload("res://scripts/w_tap.gd")

const BG := Color("#0a0818")
const CARD := Color("#171332")
const CARD2 := Color(0.118, 0.098, 0.251, 0.78)
const LINE := Color("#2d2757")
const TX := Color("#f5f2ff")
const MUT := Color("#9e98cc")
const PINK := Color("#ff3d81")
const VIOLET := Color("#7c5cff")
const GREEN := Color("#2ee6a6")
const BLUE := Color("#3aa0ff")
const GOLD := Color("#ffd24a")

static var _icons := {}

static var _theme: Theme = null


static func icon(name: String) -> Texture2D:
	if not _icons.has(name):
		_icons[name] = load("res://assets/ui/" + name + ".png")
	return _icons[name]


static func sbox(bg: Color, border: Color = Color(0, 0, 0, 0), bw: int = 0, radius: int = 14, pad: int = 12) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(bw)
	s.set_corner_radius_all(radius)
	s.set_content_margin_all(pad)
	s.anti_aliasing = true
	return s


static func theme() -> Theme:
	if _theme != null:
		return _theme
	var t := Theme.new()
	t.default_font_size = 22
	t.set_color("font_color", "Label", TX)
	t.set_font_size("font_size", "Label", 22)
	# tombol
	t.set_font_size("font_size", "Button", 24)
	t.set_color("font_color", "Button", TX)
	t.set_color("font_hover_color", "Button", Color.WHITE)
	t.set_color("font_pressed_color", "Button", Color.WHITE)
	t.set_color("font_focus_color", "Button", TX)
	t.set_stylebox("normal", "Button", sbox(Color(0.09, 0.075, 0.2, 0.9), LINE, 2, 16, 14))
	t.set_stylebox("hover", "Button", sbox(Color(0.12, 0.1, 0.26, 0.95), VIOLET, 2, 16, 14))
	t.set_stylebox("pressed", "Button", sbox(Color(0.16, 0.12, 0.34, 1.0), PINK, 2, 16, 14))
	t.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	t.set_stylebox("disabled", "Button", sbox(Color(0.09, 0.075, 0.2, 0.5), LINE, 2, 16, 14))
	t.set_constant("h_separation", "Button", 10)
	# scroll
	t.set_stylebox("scroll", "VScrollBar", sbox(Color(1, 1, 1, 0.04), Color(0, 0, 0, 0), 0, 6, 2))
	t.set_stylebox("grabber", "VScrollBar", sbox(Color(1, 1, 1, 0.25), Color(0, 0, 0, 0), 0, 6, 2))
	t.set_stylebox("grabber_highlight", "VScrollBar", sbox(Color(1, 1, 1, 0.4), Color(0, 0, 0, 0), 0, 6, 2))
	t.set_stylebox("grabber_pressed", "VScrollBar", sbox(Color(1, 1, 1, 0.5), Color(0, 0, 0, 0), 0, 6, 2))
	t.set_stylebox("scroll", "HScrollBar", sbox(Color(1, 1, 1, 0.04), Color(0, 0, 0, 0), 0, 6, 2))
	t.set_stylebox("grabber", "HScrollBar", sbox(Color(1, 1, 1, 0.25), Color(0, 0, 0, 0), 0, 6, 2))
	t.set_stylebox("grabber_highlight", "HScrollBar", sbox(Color(1, 1, 1, 0.4), Color(0, 0, 0, 0), 0, 6, 2))
	t.set_stylebox("grabber_pressed", "HScrollBar", sbox(Color(1, 1, 1, 0.5), Color(0, 0, 0, 0), 0, 6, 2))
	# progress bar
	t.set_stylebox("background", "ProgressBar", sbox(CARD, Color(0, 0, 0, 0), 0, 8, 2))
	t.set_stylebox("fill", "ProgressBar", sbox(PINK, Color(0, 0, 0, 0), 0, 8, 2))
	_theme = t
	return t


static func label(text: String, size: int = 22, color: Color = TX, align: HorizontalAlignment = HORIZONTAL_ALIGNMENT_LEFT) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.horizontal_alignment = align
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


static func button(text: String, size: int = 24, min_size: Vector2 = Vector2(0, 64)) -> Button:
	var b := Button.new()
	b.text = text
	b.add_theme_font_size_override("font_size", size)
	b.custom_minimum_size = min_size
	b.focus_mode = Control.FOCUS_NONE
	return b


## Tombol utama (gradien pink) seperti .btn di versi web.
static func primary_button(text: String, size: int = 28, min_size: Vector2 = Vector2(320, 72)) -> Button:
	var b := button(text, size, min_size)
	var n := sbox(PINK, Color(1, 1, 1, 0.25), 2, 999, 16)
	n.shadow_color = Color(1.0, 0.24, 0.5, 0.4)
	n.shadow_size = 14
	var h := sbox(Color("#ff5c96"), Color(1, 1, 1, 0.4), 2, 999, 16)
	h.shadow_color = n.shadow_color
	h.shadow_size = 18
	var p := sbox(Color("#d92f6c"), Color(1, 1, 1, 0.3), 2, 999, 16)
	b.add_theme_stylebox_override("normal", n)
	b.add_theme_stylebox_override("hover", h)
	b.add_theme_stylebox_override("pressed", p)
	return b


static func ghost_button(text: String, size: int = 22, min_size: Vector2 = Vector2(0, 56)) -> Button:
	var b := button(text, size, min_size)
	b.add_theme_stylebox_override("normal", sbox(Color(0, 0, 0, 0), LINE, 2, 999, 14))
	return b


static func icon_rect(name: String, px: int = 40, tint: Color = Color.WHITE) -> TextureRect:
	var r := TextureRect.new()
	r.texture = icon(name)
	r.custom_minimum_size = Vector2(px, px)
	r.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	r.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	r.modulate = tint
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return r


## Tombol dengan ikon + teks (mis. "< Back").
static func icon_button(icon_name: String, text: String, size: int = 22, min_size: Vector2 = Vector2(0, 60)) -> Button:
	var b := button(text, size, min_size)
	b.icon = icon(icon_name)
	b.expand_icon = true
	b.add_theme_constant_override("icon_max_width", 28)
	return b


static func spacer(h: float = 0.0, w: float = 0.0, expand: bool = false) -> Control:
	var c := Control.new()
	c.custom_minimum_size = Vector2(w, h)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	if expand:
		c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		c.size_flags_vertical = Control.SIZE_EXPAND_FILL
	return c


static func hbox(sep: int = 12) -> HBoxContainer:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", sep)
	return h


static func vbox(sep: int = 12) -> VBoxContainer:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", sep)
	return v


static func panel(bg: Color = CARD2, border: Color = Color(0.486, 0.36, 1.0, 0.35), radius: int = 20, pad: int = 16) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", sbox(bg, border, 1, radius, pad))
	return p


static func seg_style(button_ref: Button, on: bool, accent: Color = VIOLET) -> void:
	if on:
		button_ref.add_theme_stylebox_override("normal", sbox(accent.darkened(0.55), accent, 3, 16, 12))
		button_ref.add_theme_stylebox_override("hover", sbox(accent.darkened(0.5), accent, 3, 16, 12))
	else:
		button_ref.remove_theme_stylebox_override("normal")
		button_ref.remove_theme_stylebox_override("hover")


static func clear_children(n: Node) -> void:
	for c in n.get_children():
		n.remove_child(c)
		c.queue_free()
