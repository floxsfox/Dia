extends "res://scripts/s_base.gd"
## Menu utama: 3 kartu besar (Play, Achievements, Settings).

const C = preload("res://scripts/consts.gd")

const LOGO_SHADER := """
shader_type canvas_item;
void fragment() {
	float h = fract(UV.x * 0.6 + TIME * 0.12);
	vec3 k = clamp(abs(fract(vec3(h) + vec3(1.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0) - 1.0, 0.0, 1.0);
	COLOR = vec4(mix(vec3(1.0), k, 0.7), COLOR.a);
}
"""

var _ach_sub: Label
var _lib_sub: Label


func _ready() -> void:
	var col := UI.vbox(14)
	col.alignment = BoxContainer.ALIGNMENT_CENTER
	mc.add_child(col)
	var row := UI.hbox(0)
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	var b := UI.label("Drop", 92, Color.WHITE)
	var sh := Shader.new()
	sh.code = LOGO_SHADER
	var m := ShaderMaterial.new()
	m.shader = sh
	b.material = m
	row.add_child(UI.label("Beat", 92, UI.TX))
	row.add_child(b)
	col.add_child(row)
	col.add_child(UI.label("Turn any song into a rhythm game", 24, UI.MUT, HORIZONTAL_ALIGNMENT_CENTER))
	col.add_child(UI.spacer(18))
	var cards := UI.hbox(26)
	cards.alignment = BoxContainer.ALIGNMENT_CENTER
	col.add_child(cards)
	_lib_sub = UI.label("", 19, UI.MUT, HORIZONTAL_ALIGNMENT_CENTER)
	_ach_sub = UI.label("", 19, UI.MUT, HORIZONTAL_ALIGNMENT_CENTER)
	cards.add_child(_card("play", "Play", _lib_sub, "lib", UI.PINK))
	cards.add_child(_card("trophy", "Achievements", _ach_sub, "ach", UI.GOLD))
	cards.add_child(_card("gear", "Settings", UI.label("Colors, shapes, graphics", 19, UI.MUT, HORIZONTAL_ALIGNMENT_CENTER), "settings", UI.BLUE))
	col.add_child(UI.spacer(10))
	col.add_child(UI.label("Works offline  -  songs & cache saved on your device", 18, Color(1, 1, 1, 0.35), HORIZONTAL_ALIGNMENT_CENTER))


func _card(icon: String, title: String, sub: Label, target: String, tint: Color) -> Button:
	var b := Button.new()
	b.custom_minimum_size = Vector2(290, 310)
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_stylebox_override("normal", UI.sbox(Color(0.09, 0.075, 0.2, 0.88), tint.darkened(0.35), 3, 30, 16))
	b.add_theme_stylebox_override("hover", UI.sbox(Color(0.12, 0.1, 0.26, 0.95), tint, 3, 30, 16))
	b.add_theme_stylebox_override("pressed", UI.sbox(Color(0.16, 0.12, 0.34, 1.0), tint, 4, 30, 16))
	var v := UI.vbox(10)
	v.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(UI.icon_rect(icon, 128, tint))
	v.add_child(UI.label(title, 32, UI.TX, HORIZONTAL_ALIGNMENT_CENTER))
	v.add_child(sub)
	b.add_child(v)
	b.pressed.connect(func():
		Sfx.click()
		nav.emit(target, {}))
	return b


func on_enter(_args: Dictionary = {}) -> void:
	var n := Store.library.size()
	_lib_sub.text = "%d song%s saved" % [n, "" if n == 1 else "s"]
	_ach_sub.text = "%d / %d unlocked" % [Store.achv.size(), C.ACHV.size()]


func on_back() -> void:
	nav.emit("quit", {})
