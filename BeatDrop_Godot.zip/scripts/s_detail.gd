extends "res://scripts/s_base.gd"
## Pengaturan sebelum main: level, akurasi, kecepatan, sinkron, START.

const C = preload("res://scripts/consts.gd")

var song_id := ""
var sel_diff := 1
var _counts: Array = [0, 0, 0]

var _cover: TextureRect
var _cover_ph: Control
var _title: Label
var _meta: Label
var _best: Label
var _grades: HBoxContainer
var _diff_btns: Array = []
var _acc_btns: Array = []
var _spd_sl
var _spd_lbl: Label
var _sync_sl
var _sync_lbl: Label
var _gen_lbl: Label


func _ready() -> void:
	var col := UI.vbox(12)
	mc.add_child(col)
	col.add_child(header("", "", "lib"))
	var body := UI.hbox(28)
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	col.add_child(body)
	# ---- kiri: sampul + info
	var left := UI.vbox(10)
	left.custom_minimum_size = Vector2(300, 0)
	body.add_child(left)
	var cov := Control.new()
	cov.custom_minimum_size = Vector2(280, 280)
	cov.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_cover_ph = ColorRect.new()
	_cover_ph.color = Color(0.486, 0.36, 1.0, 0.25)
	_cover_ph.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_cover_ph.mouse_filter = Control.MOUSE_FILTER_IGNORE
	cov.add_child(_cover_ph)
	var ic := UI.icon_rect("note", 120, Color(1, 1, 1, 0.8))
	ic.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	ic.offset_left = -60
	ic.offset_right = 60
	ic.offset_top = -60
	ic.offset_bottom = 60
	_cover_ph.add_child(ic)
	_cover = TextureRect.new()
	_cover.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_cover.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	_cover.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_cover.mouse_filter = Control.MOUSE_FILTER_IGNORE
	cov.add_child(_cover)
	left.add_child(cov)
	_title = UI.label("", 30, UI.TX)
	_title.custom_minimum_size = Vector2(280, 0)
	_title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	left.add_child(_title)
	_meta = UI.label("", 20, UI.MUT)
	left.add_child(_meta)
	_best = UI.label("", 22, UI.GOLD)
	left.add_child(_best)
	_grades = UI.hbox(6)
	left.add_child(_grades)
	# ---- kanan: kontrol
	var sc := ScrollContainer.new()
	sc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	body.add_child(sc)
	var right := UI.vbox(12)
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(right)
	right.add_child(UI.label("Difficulty", 22, UI.MUT))
	var dr := UI.hbox(10)
	for i in 3:
		var b := UI.button("", 22, Vector2(0, 92))
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.pressed.connect(func():
			Sfx.click()
			_pick_diff(i))
		_diff_btns.append(b)
		dr.add_child(b)
	right.add_child(dr)
	right.add_child(UI.label("Accuracy", 22, UI.MUT))
	var ar := UI.hbox(10)
	for i in 3:
		var b := UI.button(String(C.ACC_N[i]), 22, Vector2(0, 60))
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.pressed.connect(func():
			Sfx.click()
			Store.SET["acc"] = i
			Store.save_soon()
			_refresh_acc())
		_acc_btns.append(b)
		ar.add_child(b)
	right.add_child(ar)
	_spd_lbl = UI.label("", 22, UI.MUT)
	right.add_child(_spd_lbl)
	_spd_sl = _slider_row(right, 0.5, 2.0, 0.05, 0.05)
	_spd_sl.value_changed.connect(func(v: float):
		Store.SET["spd"] = snappedf(v, 0.05)
		Store.save_soon()
		_refresh_labels())
	_sync_lbl = UI.label("", 22, UI.MUT)
	right.add_child(_sync_lbl)
	_sync_sl = _slider_row(right, -300.0, 300.0, 5.0, 5.0)
	_sync_sl.value_changed.connect(func(v: float):
		Store.sync_ms = int(v)
		Store.stats["sync"] = 1
		Store.save_soon()
		_refresh_labels())
	_gen_lbl = UI.label("", 18, Color(1, 1, 1, 0.4))
	right.add_child(_gen_lbl)
	var sr := UI.hbox(14)
	var start := UI.primary_button("START", 32, Vector2(0, 78))
	start.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	start.pressed.connect(func():
		Sfx.click()
		nav.emit("start", {"diff": sel_diff}))
	sr.add_child(start)
	var del := UI.icon_button("trash", "", 22, Vector2(78, 78))
	del.pressed.connect(_on_delete)
	sr.add_child(del)
	right.add_child(sr)


func _slider_row(parent: Control, mn: float, mx: float, st: float, nudge: float) -> Control:
	var r := UI.hbox(8)
	var minus := UI.button("-", 30, Vector2(64, 56))
	var sl := preload("res://scripts/w_slider.gd").new()
	sl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sl.setup(mn, mx, st, mn)
	var plus := UI.button("+", 30, Vector2(64, 56))
	minus.pressed.connect(func(): sl.nudge(-nudge))
	plus.pressed.connect(func(): sl.nudge(nudge))
	r.add_child(minus)
	r.add_child(sl)
	r.add_child(plus)
	parent.add_child(r)
	return sl


func on_enter(args: Dictionary = {}) -> void:
	song_id = String(args.get("id", song_id))
	_counts = args.get("counts", _counts)
	if args.has("diff"):
		sel_diff = int(args["diff"])
	var e := Store.find_song(song_id)
	if e.is_empty():
		nav.emit("lib", {})
		return
	_title.text = String(e["name"])
	_meta.text = "%s  -  %.1f MB" % [C.fmt_dur(float(e["dur"])), float(e["bytes"]) / 1048576.0]
	var tex := Store.thumb_texture(song_id)
	_cover.texture = tex
	_cover.visible = tex != null
	_spd_sl.set_value_silent(float(Store.SET["spd"]))
	_sync_sl.set_value_silent(float(Store.sync_ms))
	var gn: String = ["V1 Beat", "V2 Bass (Beta)", "V3 Melody (Beta)"][clampi(int(args.get("gen", Store.SET["gen"])) - 1, 0, 2)]
	_gen_lbl.text = "Note generator: %s  (change in Settings > Graphics)" % gn
	UI.clear_children(_grades)
	var gc := Store.grade_counts(song_id)
	for i in range(C.GRS.size() - 1, -1, -1):
		var g: String = C.GRS[i]
		if int(gc.get(g, 0)) > 0:
			_grades.add_child(UI.label("%s x%d" % [g, int(gc[g])], 19, C.grade_color(g)))
	_refresh_diff()
	_refresh_acc()
	_refresh_labels()


func _pick_diff(i: int) -> void:
	sel_diff = i
	_refresh_diff()


func _refresh_diff() -> void:
	for i in 3:
		var b: Button = _diff_btns[i]
		var n := int(_counts[i]) if _counts.size() > i else 0
		b.text = "%s\n%s - %d notes" % [C.DIFF_N[i], C.DIFF_SUB[i], n]
		b.add_theme_font_size_override("font_size", 22)
		UI.seg_style(b, i == sel_diff, UI.PINK)
	var bs := Store.best_get(song_id, sel_diff)
	_best.text = ("Best (%s): %s" % [C.DIFF_N[sel_diff], C.fmt_int(bs)]) if bs > 0 else "No score yet on %s" % C.DIFF_N[sel_diff]


func _refresh_acc() -> void:
	for i in 3:
		UI.seg_style(_acc_btns[i], i == int(Store.SET["acc"]))


func _refresh_labels() -> void:
	_spd_lbl.text = "Drop speed: %.2fx" % float(Store.SET["spd"])
	var s := Store.sync_ms
	_sync_lbl.text = "Audio sync: %s%d ms   (raise if notes feel early/late)" % ["+" if s > 0 else "", s]


func _on_delete() -> void:
	Sfx.click()
	var e := Store.find_song(song_id)
	if e.is_empty():
		return
	var dlg := ConfirmationDialog.new()
	dlg.title = "Delete song"
	dlg.dialog_text = "Delete \"%s\" from this device? Its scores and cache are removed too." % String(e["name"])
	dlg.ok_button_text = "Delete"
	dlg.cancel_button_text = "Cancel"
	add_child(dlg)
	dlg.confirmed.connect(func():
		dlg.queue_free()
		Store.remove_song(song_id)
		toast_req.emit("Song deleted")
		nav.emit("lib", {}))
	dlg.canceled.connect(func(): dlg.queue_free())
	dlg.popup_centered(Vector2i(640, 260))


func on_back() -> void:
	nav.emit("lib", {})
