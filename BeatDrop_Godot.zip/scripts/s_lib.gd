extends "res://scripts/s_base.gd"
## Perpustakaan lagu: kartu bisa digeser; ketuk untuk membuka, tombol Upload membuka file manager.

const C = preload("res://scripts/consts.gd")

var _list: HBoxContainer
var _empty: Label
var _scroll: ScrollContainer
var _sub: Label


func _ready() -> void:
	var col := UI.vbox(16)
	mc.add_child(col)
	var h := header("Song Library", "")
	_sub = (h.get_child(1).get_child(1) as Label)
	var up := UI.primary_button("Upload", 26, Vector2(230, 64))
	up.icon = UI.icon("plus")
	up.expand_icon = true
	up.add_theme_constant_override("icon_max_width", 30)
	up.pressed.connect(func():
		Sfx.click()
		nav.emit("pick", {}))
	h.add_child(up)
	col.add_child(h)
	_scroll = ScrollContainer.new()
	_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_list = UI.hbox(22)
	_list.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_scroll.add_child(_list)
	col.add_child(_scroll)
	_empty = UI.label("No songs yet.\nTap Upload and choose an MP3 / OGG from your file manager.", 26, UI.MUT, HORIZONTAL_ALIGNMENT_CENTER)
	_empty.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_empty.size_flags_vertical = Control.SIZE_EXPAND_FILL
	col.add_child(_empty)


func on_enter(_args: Dictionary = {}) -> void:
	refresh()


func refresh() -> void:
	UI.clear_children(_list)
	var n := Store.library.size()
	_sub.text = "%d song%s  -  tap a card to play" % [n, "" if n == 1 else "s"]
	_empty.visible = n == 0
	_scroll.visible = n > 0
	for i in range(n - 1, -1, -1):
		_list.add_child(_card(Store.library[i]))


func _card(e: Dictionary) -> Control:
	var id: String = e["id"]
	var p := UI.panel(Color(0.09, 0.075, 0.2, 0.9), Color(0.486, 0.36, 1.0, 0.4), 24, 14)
	p.custom_minimum_size = Vector2(250, 0)
	p.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	var v := UI.vbox(8)
	p.add_child(v)
	var cover := Control.new()
	cover.custom_minimum_size = Vector2(222, 222)
	cover.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var tex := Store.thumb_texture(id)
	if tex != null:
		var tr := TextureRect.new()
		tr.texture = tex
		tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
		tr.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
		tr.clip_contents = true
		cover.add_child(tr)
	else:
		var cr := ColorRect.new()
		cr.color = Color(0.486, 0.36, 1.0, 0.25)
		cr.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		cr.mouse_filter = Control.MOUSE_FILTER_IGNORE
		cover.add_child(cr)
		var ic := UI.icon_rect("note", 110, Color(1, 1, 1, 0.8))
		ic.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
		ic.offset_left = -55
		ic.offset_right = 55
		ic.offset_top = -55
		ic.offset_bottom = 55
		cover.add_child(ic)
	v.add_child(cover)
	var nm := UI.label(String(e["name"]), 24, UI.TX)
	nm.custom_minimum_size = Vector2(222, 0)
	nm.clip_text = true
	nm.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	v.add_child(nm)
	var meta := UI.label("%s  -  %.1f MB" % [C.fmt_dur(float(e["dur"])), float(e["bytes"]) / 1048576.0], 19, UI.MUT)
	v.add_child(meta)
	var g := Store.grade_best(id)
	var gl := UI.label(("Best grade: " + g) if g != "" else "Not played yet", 20, C.grade_color(g) if g != "" else UI.MUT)
	v.add_child(gl)
	var tap := preload("res://scripts/w_tap.gd").new()
	tap.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	tap.tapped.connect(func():
		Sfx.click()
		nav.emit("open_song", {"id": id}))
	p.add_child(tap)
	return p
