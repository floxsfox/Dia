extends "res://scripts/s_base.gd"
## Pengaturan: Colors, Shapes, Camera, Effects, Graphics (resolusi, FPS, generator not, penyimpanan).

signal changed

const C = preload("res://scripts/consts.gd")
const WSlider = preload("res://scripts/w_slider.gd")
const WSwitch = preload("res://scripts/w_switch.gd")
const WWheel = preload("res://scripts/w_wheel.gd")
const TABS := ["Colors", "Shapes", "Camera", "Effects", "Graphics"]
const RES_KEYS := [40, 50, 75, 100]

var _holder: VBoxContainer
var _tab_btns: Array = []
var _pages: Array = []
var _wheel
var _lane_btns: Array = []
var _sel_lane := 0
var _sat_lbl: Label
var _sat_sl
var _tilt_lbl: Label
var _tilt_sl
var _cache_lbl: Label
var _v2_box: VBoxContainer
var _v3_box: VBoxContainer


func _ready() -> void:
	var col := UI.vbox(12)
	mc.add_child(col)
	col.add_child(header("Settings", "Customize your game"))
	var tr := UI.hbox(8)
	for i in TABS.size():
		var b := UI.button(String(TABS[i]), 22, Vector2(0, 58))
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.pressed.connect(func():
			Sfx.click()
			_show_tab(i))
		_tab_btns.append(b)
		tr.add_child(b)
	col.add_child(tr)
	_holder = UI.vbox(0)
	_holder.size_flags_vertical = Control.SIZE_EXPAND_FILL
	col.add_child(_holder)
	_build_colors()
	_build_shapes()
	_build_camera()
	_build_effects()
	_build_graphics()
	_show_tab(0)


func _page() -> VBoxContainer:
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	var v := UI.vbox(14)
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(v)
	_holder.add_child(sc)
	_pages.append(sc)
	return v


func _show_tab(i: int) -> void:
	for k in _pages.size():
		_pages[k].visible = k == i
		UI.seg_style(_tab_btns[k], k == i, UI.PINK)


func on_enter(_args: Dictionary = {}) -> void:
	_refresh_colors()
	_refresh_cache()


# ---------------------------------------------------------------- helpers

func _seg(names: Array, cur: int, on_pick: Callable) -> HBoxContainer:
	var h := UI.hbox(10)
	var btns: Array = []
	for i in names.size():
		var b := UI.button(String(names[i]), 22, Vector2(0, 64))
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		UI.seg_style(b, i == cur)
		b.pressed.connect(func():
			Sfx.click()
			for j in btns.size():
				UI.seg_style(btns[j], j == i)
			on_pick.call(i))
		btns.append(b)
		h.add_child(b)
	return h


func _toggle_row(parent: Control, title: String, hint: String, key: String) -> void:
	var p := UI.panel(Color(0.09, 0.075, 0.2, 0.85), UI.LINE, 18, 14)
	var h := UI.hbox(16)
	p.add_child(h)
	var v := UI.vbox(2)
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_child(UI.label(title, 24, UI.TX))
	if hint != "":
		v.add_child(UI.label(hint, 18, UI.MUT))
	h.add_child(v)
	var sw := WSwitch.new()
	sw.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	sw.set_on(bool(Store.SET[key]))
	sw.toggled.connect(func(on: bool):
		Sfx.click()
		Store.SET[key] = on
		Store.save_soon()
		changed.emit())
	h.add_child(sw)
	parent.add_child(p)


func _val_slider(parent: Control, title: String, key: String, mn: float, mx: float, st: float, unit: String) -> void:
	var lbl := UI.label("", 22, UI.MUT)
	parent.add_child(lbl)
	var sl := WSlider.new()
	sl.setup(mn, mx, st, float(Store.SET[key]))
	var upd := func(v: float): lbl.text = "%s: %d%s" % [title, int(v), unit]
	upd.call(sl.value)
	sl.value_changed.connect(func(v: float):
		Store.SET[key] = int(v)
		Store.save_soon()
		upd.call(v))
	parent.add_child(sl)


# ---------------------------------------------------------------- Colors

func _build_colors() -> void:
	var v := _page()
	var h := UI.hbox(30)
	v.add_child(h)
	_wheel = WWheel.new()
	_wheel.custom_minimum_size = Vector2(340, 340)
	_wheel.picked.connect(_on_wheel)
	h.add_child(_wheel)
	var r := UI.vbox(12)
	r.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(r)
	r.add_child(UI.label("Tap a lane, then pick its color on the wheel", 20, UI.MUT))
	var lr := UI.hbox(8)
	for i in 5:
		var b := Button.new()
		b.text = String(C.LABELS[i])
		b.focus_mode = Control.FOCUS_NONE
		b.custom_minimum_size = Vector2(0, 76)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.add_theme_font_size_override("font_size", 24)
		b.pressed.connect(func():
			Sfx.click()
			_sel_lane = i
			_refresh_colors())
		_lane_btns.append(b)
		lr.add_child(b)
	r.add_child(lr)
	_sat_lbl = UI.label("", 22, UI.MUT)
	r.add_child(_sat_lbl)
	_sat_sl = WSlider.new()
	_sat_sl.setup(0.0, 100.0, 1.0, 100.0)
	_sat_sl.value_changed.connect(func(val: float):
		var o: Dictionary = Store.hsl[_sel_lane]
		Store.set_lane_hsl(_sel_lane, float(o["h"]), val, float(o["l"]))
		Store.stats["colors"] = 1
		_refresh_colors()
		changed.emit())
	r.add_child(_sat_sl)
	r.add_child(UI.label("Presets", 22, UI.MUT))
	var pr := UI.hbox(8)
	for nm in C.PALS:
		var b := UI.button(String(nm), 20, Vector2(0, 58))
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.pressed.connect(func():
			Sfx.click()
			Store.set_palette(C.PALS[nm])
			_refresh_colors()
			changed.emit())
		pr.add_child(b)
	r.add_child(pr)


func _on_wheel(hue: float, light: float) -> void:
	var o: Dictionary = Store.hsl[_sel_lane]
	Store.set_lane_hsl(_sel_lane, hue, float(o["s"]), light)
	Store.stats["colors"] = 1
	_refresh_colors()
	changed.emit()


func _refresh_colors() -> void:
	if _wheel == null:
		return
	for i in 5:
		var c: Color = Store.colors[i]
		var b: Button = _lane_btns[i]
		var sel := i == _sel_lane
		var sb := UI.sbox(c, Color.WHITE if sel else Color(1, 1, 1, 0.15), 5 if sel else 2, 16, 8)
		b.add_theme_stylebox_override("normal", sb)
		b.add_theme_stylebox_override("hover", sb)
		b.add_theme_stylebox_override("pressed", sb)
		var dark := c.get_luminance() > 0.55
		b.add_theme_color_override("font_color", Color(0.05, 0.04, 0.12) if dark else Color.WHITE)
		b.add_theme_color_override("font_hover_color", Color(0.05, 0.04, 0.12) if dark else Color.WHITE)
		b.add_theme_color_override("font_pressed_color", Color(0.05, 0.04, 0.12) if dark else Color.WHITE)
	var o: Dictionary = Store.hsl[_sel_lane]
	_wheel.set_state(float(o["h"]), float(o["l"]), float(o["s"]), Store.colors[_sel_lane])
	_sat_sl.set_value_silent(float(o["s"]))
	_sat_lbl.text = "Saturation: %d%%" % int(o["s"])


# ---------------------------------------------------------------- Shapes

func _build_shapes() -> void:
	var v := _page()
	v.add_child(UI.label("Beat hole (target at the hit line)", 22, UI.MUT))
	v.add_child(_seg(C.HOLE_N, int(Store.SET["hole"]), _on_hole))
	v.add_child(UI.spacer(10))
	v.add_child(UI.label("Note shape", 22, UI.MUT))
	var names: Array = []
	var cur := 0
	for k in C.NSHAPE_OPTS.size():
		names.append(C.NSHAPE_OPTS[k][1])
		if int(C.NSHAPE_OPTS[k][0]) == int(Store.SET["nshape"]):
			cur = k
	v.add_child(_seg(names, cur, _on_nshape))
	v.add_child(UI.label("Changes apply the next time you start a song.", 18, Color(1, 1, 1, 0.4)))


func _on_hole(i: int) -> void:
	Store.SET["hole"] = i
	Store.save_soon()
	changed.emit()


func _on_nshape(i: int) -> void:
	Store.SET["nshape"] = int(C.NSHAPE_OPTS[i][0])
	Store.save_soon()
	changed.emit()


# ---------------------------------------------------------------- Camera

func _build_camera() -> void:
	var v := _page()
	_tilt_lbl = UI.label("", 24, UI.TX)
	v.add_child(_tilt_lbl)
	_tilt_sl = WSlider.new()
	_tilt_sl.setup(0.0, 100.0, 5.0, float(Store.SET["tilt"]))
	_tilt_sl.value_changed.connect(func(val: float):
		Store.SET["tilt"] = int(val)
		Store.save_soon()
		_upd_tilt()
		changed.emit())
	v.add_child(_tilt_sl)
	v.add_child(UI.label("Tilts the playfield like a 3D highway. 0 = flat 2D.", 18, UI.MUT))
	_upd_tilt()


func _upd_tilt() -> void:
	var t := int(Store.SET["tilt"])
	_tilt_lbl.text = "Camera tilt: " + (("%d%%" % t) if t > 0 else "Off")


# ---------------------------------------------------------------- Effects

func _build_effects() -> void:
	var v := _page()
	_toggle_row(v, "Particles", "Sparks and glowing fluid on hits", "parts")
	_toggle_row(v, "Lane glow", "Lane lights up while you press, background pulses with bass", "glow")
	_toggle_row(v, "Vibration", "Short haptic tick on every hit", "vib")


# ---------------------------------------------------------------- Graphics + generator + storage

func _build_graphics() -> void:
	var v := _page()
	v.add_child(UI.label("Game resolution", 22, UI.MUT))
	var names: Array = []
	var cur := 1
	for k in RES_KEYS.size():
		names.append(C.RES_NAME[RES_KEYS[k]])
		if RES_KEYS[k] == int(Store.SET["res"]):
			cur = k
	v.add_child(_seg(names, cur, _on_res))
	v.add_child(UI.label("HD 720p is the default: sharp and smooth. Use Saver if your phone drops frames.", 18, UI.MUT))
	_toggle_row(v, "Adaptive quality", "Automatically lowers render size if FPS dips, restores when stable", "aq")
	v.add_child(UI.label("Frame rate is locked to 60 FPS (VSync) for stable timing.", 18, Color(1, 1, 1, 0.4)))
	v.add_child(UI.spacer(8))
	v.add_child(UI.label("Note generator", 22, UI.MUT))
	v.add_child(_seg(["V1 Beat", "V2 Bass (Beta)", "V3 Melody (Beta)"], int(Store.SET["gen"]) - 1, _on_gen))
	_v2_box = UI.vbox(8)
	_val_slider(_v2_box, "Sensitivity", "v2th", 0.0, 100.0, 5.0, "")
	_val_slider(_v2_box, "Min gap between notes", "v2cd", 100.0, 600.0, 10.0, " ms")
	_v2_box.visible = int(Store.SET["gen"]) == 2
	v.add_child(_v2_box)
	_v3_box = UI.vbox(8)
	_val_slider(_v3_box, "Sensitivity", "v3th", 0.0, 100.0, 5.0, "")
	_val_slider(_v3_box, "Hold note length", "v3hl", 20.0, 150.0, 5.0, "%")
	_v3_box.visible = int(Store.SET["gen"]) == 3
	v.add_child(_v3_box)
	v.add_child(UI.label("The first time a song is analyzed it can take a while; results are cached on the device.", 18, UI.MUT))
	v.add_child(UI.spacer(8))
	v.add_child(UI.label("Storage", 22, UI.MUT))
	_cache_lbl = UI.label("", 20, UI.TX)
	v.add_child(_cache_lbl)
	var cb := UI.button("Clear analysis cache", 22, Vector2(0, 60))
	cb.pressed.connect(func():
		Sfx.click()
		Store.cache_clear()
		_refresh_cache()
		toast_req.emit("Cache cleared"))
	v.add_child(cb)


func _on_res(i: int) -> void:
	Store.SET["res"] = RES_KEYS[i]
	Store.save_soon()
	changed.emit()


func _on_gen(i: int) -> void:
	Store.SET["gen"] = i + 1
	Store.save_soon()
	_v2_box.visible = i == 1
	_v3_box.visible = i == 2


func _refresh_cache() -> void:
	if _cache_lbl == null:
		return
	var total := 0
	for e in Store.library:
		total += int(e["bytes"])
	_cache_lbl.text = "Songs: %d (%.1f MB)   -   Analysis cache: %.1f MB" % [Store.library.size(), float(total) / 1048576.0, float(Store.cache_bytes()) / 1048576.0]
