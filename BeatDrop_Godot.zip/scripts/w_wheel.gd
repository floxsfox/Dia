extends Control
## Roda warna HSL (sudut = hue, jari-jari = lightness) digambar oleh shader.

signal picked(h: float, l: float)

const SHADER := """
shader_type canvas_item;
uniform float sat = 1.0;
uniform float ri = 0.224;
uniform float ro = 0.372;
uniform float lmin = 0.30;
uniform float lmax = 0.90;
vec3 hsl2rgb(float h, float s, float l) {
	float q = l < 0.5 ? l * (1.0 + s) : l + s - l * s;
	float p = 2.0 * l - q;
	vec3 t = vec3(h + 1.0 / 3.0, h, h - 1.0 / 3.0);
	vec3 c = vec3(0.0);
	for (int i = 0; i < 3; i++) {
		float tt = fract(t[i]);
		float v = p;
		if (tt < 1.0 / 6.0) v = p + (q - p) * 6.0 * tt;
		else if (tt < 0.5) v = q;
		else if (tt < 2.0 / 3.0) v = p + (q - p) * (2.0 / 3.0 - tt) * 6.0;
		c[i] = v;
	}
	return c;
}
void fragment() {
	vec2 d = UV - vec2(0.5);
	float dist = length(d);
	float ang = fract(atan(d.x, -d.y) / 6.28318530718);
	float r = clamp((ro - dist) / (ro - ri), 0.0, 1.0);
	float l = mix(lmin, lmax, r);
	float aa = 0.004;
	float a = smoothstep(ri - aa, ri + aa, dist) * (1.0 - smoothstep(ro - aa, ro + aa, dist));
	COLOR = vec4(hsl2rgb(ang, sat, l), a);
}
"""

const RI := 0.224
const RO := 0.372
const LMIN := 30.0
const LMAX := 90.0

var hue := 0.0
var light := 60.0
var marker_color := Color.WHITE
var _rect: ColorRect
var _mat: ShaderMaterial
var _drag := false


func _init() -> void:
	custom_minimum_size = Vector2(300, 300)
	mouse_filter = Control.MOUSE_FILTER_STOP
	_rect = ColorRect.new()
	_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sh := Shader.new()
	sh.code = SHADER
	_mat = ShaderMaterial.new()
	_mat.shader = sh
	_rect.material = _mat
	add_child(_rect)


func set_state(h: float, l: float, sat_percent: float, col: Color) -> void:
	hue = h
	light = l
	marker_color = col
	_mat.set_shader_parameter("sat", sat_percent / 100.0)
	queue_redraw()


func _pick(pos: Vector2) -> void:
	var dx := pos.x / size.x - 0.5
	var dy := pos.y / size.y - 0.5
	var dist := sqrt(dx * dx + dy * dy)
	var ang := fposmod(rad_to_deg(atan2(dx, -dy)), 360.0)
	var r := clampf((RO - dist) / (RO - RI), 0.0, 1.0)
	picked.emit(ang, LMIN + r * (LMAX - LMIN))


func _gui_input(e: InputEvent) -> void:
	if e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT:
		if e.pressed:
			var dx: float = e.position.x / size.x - 0.5
			var dy: float = e.position.y / size.y - 0.5
			var dist := sqrt(dx * dx + dy * dy)
			if dist >= RI - 0.04 and dist <= RO + 0.1:
				_drag = true
				_pick(e.position)
		else:
			_drag = false
		accept_event()
	elif e is InputEventMouseMotion and _drag:
		_pick(e.position)
		accept_event()


func _draw() -> void:
	var r := clampf((light - LMIN) / (LMAX - LMIN), 0.0, 1.0)
	var dist := RO - r * (RO - RI)
	var t := deg_to_rad(hue)
	var c := size * 0.5 + Vector2(sin(t), -cos(t)) * dist * size
	draw_circle(c, 17.0, Color(0, 0, 0, 0.5))
	draw_circle(c, 15.0, Color.WHITE)
	draw_circle(c, 10.0, marker_color)
