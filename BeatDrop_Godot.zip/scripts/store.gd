extends Node
## Penyimpanan permanen + cache di user:// (autoload "Store").
## Semua data tersimpan di perangkat sehingga game jalan offline.

const C = preload("res://scripts/consts.gd")

const ROOT := "user://beatdrop"
const SAVE_PATH := ROOT + "/save.json"
const LIB_PATH := ROOT + "/library.json"
const SONGS_DIR := ROOT + "/songs"
const THUMBS_DIR := ROOT + "/thumbs"
const CACHE_DIR := ROOT + "/cache"
const CACHE_VER := 3

var SET: Dictionary = {}
var stats: Dictionary = {}
var sg: Dictionary = {}          # riwayat nilai per lagu: {id: {"S": 2, ...}}
var achv: Array = []             # id prestasi yang terbuka
var best: Dictionary = {}        # "id:diff" -> skor terbaik
var sync_ms: int = 0
var library: Array = []          # [{id,name,ext,dur,bytes,thumb,added}]
var hsl: Array = []              # 5 x {h,s,l}
var colors: Array = []           # 5 x Color

var _dirty := false
var _dirty_t := 0.0
var _thumb_cache := {}


func _ready() -> void:
	Engine.max_fps = C.FPS_CAP
	for d in [ROOT, SONGS_DIR, THUMBS_DIR, CACHE_DIR]:
		DirAccess.make_dir_recursive_absolute(d)
	_load_all()
	set_physics_process(false)


func _process(delta: float) -> void:
	if _dirty:
		_dirty_t += delta
		if _dirty_t > 1.0:
			save_now()


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST:
		save_now()


# ------------------------------------------------------------------ default data

func _default_set() -> Dictionary:
	return {
		"parts": true, "glow": true, "vib": true, "hole": 0, "nshape": 0, "tilt": 40,
		"acc": 1, "spd": 1.0, "res": 50, "aq": true, "gen": 1,
		"v2th": 50, "v2cd": 250, "v3th": 50, "v3hl": 60,
	}


func _default_stats() -> Dictionary:
	return {
		"plays": 0, "hits": 0, "perfects": 0, "greats": 0, "goods": 0, "misses": 0, "bestCombo": 0,
		"grades": {}, "fc": [0, 0, 0], "clear": [0, 0, 0], "maxScore": 0, "bestAcc": 0.0, "holds": 0,
		"fails": 0, "previews": 0, "colors": 0, "songs": 0, "night": 0, "lowhp": 0, "pauses": 0,
		"sync": 0, "diffs": [],
	}


# ------------------------------------------------------------------ load / save

func _read_json(path: String) -> Variant:
	if not FileAccess.file_exists(path):
		return null
	var txt := FileAccess.get_file_as_string(path)
	if txt == "":
		return null
	return JSON.parse_string(txt)


func _write_json(path: String, data: Variant) -> void:
	var tmp := path + ".tmp"
	var f := FileAccess.open(tmp, FileAccess.WRITE)
	if f == null:
		return
	f.store_string(JSON.stringify(data))
	f.close()
	DirAccess.rename_absolute(tmp, path)


func _load_all() -> void:
	SET = _default_set()
	stats = _default_stats()
	var d = _read_json(SAVE_PATH)
	if d is Dictionary:
		if d.get("set") is Dictionary:
			SET.merge(d["set"], true)
		if d.get("stats") is Dictionary:
			stats.merge(d["stats"], true)
		if d.get("sg") is Dictionary:
			sg = d["sg"]
		if d.get("achv") is Array:
			achv = d["achv"]
		if d.get("best") is Dictionary:
			best = d["best"]
		sync_ms = int(d.get("sync", 0))
		if d.get("hsl") is Array and d["hsl"].size() == 5:
			hsl = d["hsl"]
	_normalize()
	var lib = _read_json(LIB_PATH)
	if lib is Array:
		library = lib
		# buang entri yang file-nya hilang
		var keep: Array = []
		for e in library:
			if e is Dictionary and FileAccess.file_exists(song_path(e)):
				keep.append(e)
		library = keep


func _normalize() -> void:
	for k in ["hole", "nshape", "tilt", "acc", "res", "gen", "v2th", "v2cd", "v3th", "v3hl"]:
		SET[k] = int(SET[k])
	SET["spd"] = float(SET["spd"])
	if not C.RES_H.has(SET["res"]):
		SET["res"] = 50
	for k in ["parts", "glow", "vib", "aq"]:
		SET[k] = bool(SET[k])
	for k in ["plays", "hits", "perfects", "greats", "goods", "misses", "bestCombo", "maxScore", "holds",
			"fails", "previews", "colors", "songs", "night", "lowhp", "pauses", "sync"]:
		stats[k] = int(stats[k])
	var fc: Array = []
	var cl: Array = []
	for i in 3:
		fc.append(int(stats["fc"][i]) if stats["fc"].size() > i else 0)
		cl.append(int(stats["clear"][i]) if stats["clear"].size() > i else 0)
	stats["fc"] = fc
	stats["clear"] = cl
	var dd: Array = []
	for v in stats["diffs"]:
		dd.append(int(v))
	stats["diffs"] = dd
	# warna: dari HSL tersimpan, atau palet Neon
	var ok := hsl.size() == 5
	if ok:
		for o in hsl:
			if not (o is Dictionary and o.has("h") and o.has("s") and o.has("l")):
				ok = false
	if not ok:
		hsl = []
		for hx in C.DEFAULT_COLORS:
			hsl.append(C.color_to_hsl(Color(hx)))
	rebuild_colors()


func rebuild_colors() -> void:
	colors = []
	for o in hsl:
		colors.append(C.hsl_to_color(float(o["h"]), float(o["s"]), float(o["l"])))


func set_palette(hexes: Array) -> void:
	hsl = []
	for hx in hexes:
		hsl.append(C.color_to_hsl(Color(hx)))
	rebuild_colors()
	stats["colors"] += 1
	save_soon()


func set_lane_hsl(i: int, h: float, s: float, l: float) -> void:
	hsl[i] = {"h": roundi(h) % 360, "s": roundi(s), "l": roundi(l)}
	colors[i] = C.hsl_to_color(float(hsl[i]["h"]), float(hsl[i]["s"]), float(hsl[i]["l"]))
	save_soon()


func save_soon() -> void:
	_dirty = true


func save_now() -> void:
	_dirty = false
	_dirty_t = 0.0
	_write_json(SAVE_PATH, {
		"set": SET, "stats": stats, "sg": sg, "achv": achv, "best": best, "sync": sync_ms, "hsl": hsl,
	})
	_write_json(LIB_PATH, library)


# ------------------------------------------------------------------ library

func song_path(e: Dictionary) -> String:
	return SONGS_DIR + "/" + String(e["id"]) + "." + String(e["ext"])


func thumb_path(id: String) -> String:
	return THUMBS_DIR + "/" + id + ".jpg"


func find_song(id: String) -> Dictionary:
	for e in library:
		if e["id"] == id:
			return e
	return {}


func detect_ext(b: PackedByteArray) -> String:
	if b.size() < 4:
		return ""
	if b[0] == 0x4F and b[1] == 0x67 and b[2] == 0x67 and b[3] == 0x53:
		return "ogg"
	if b[0] == 0x49 and b[1] == 0x44 and b[2] == 0x33:
		return "mp3"
	if b[0] == 0xFF and (b[1] & 0xE0) == 0xE0:
		return "mp3"
	return ""


func make_stream(bytes: PackedByteArray, ext: String) -> AudioStream:
	if ext == "ogg":
		return AudioStreamOggVorbis.load_from_buffer(bytes)
	var s := AudioStreamMP3.new()
	s.data = bytes
	return s


func load_song_stream(id: String) -> AudioStream:
	var e := find_song(id)
	if e.is_empty():
		return null
	var bytes := FileAccess.get_file_as_bytes(song_path(e))
	if bytes.is_empty():
		return null
	return make_stream(bytes, String(e["ext"]))


## Tambah lagu dari path (bisa berupa content:// URI dari file manager Android).
## Mengembalikan {"ok": bool, "msg": String, "id": String}
func add_song(path: String) -> Dictionary:
	var bytes := FileAccess.get_file_as_bytes(path)
	if bytes.size() < 2048:
		return {"ok": false, "msg": "Could not read file."}
	var ext := detect_ext(bytes)
	if ext == "":
		ext = "mp3"
	var stream := make_stream(bytes, ext)
	if stream == null:
		return {"ok": false, "msg": "Unsupported audio. Use MP3 or OGG."}
	var dur := stream.get_length()
	if dur <= 0.0:
		return {"ok": false, "msg": "Unsupported audio. Use MP3 or OGG."}
	if dur < 10.0:
		return {"ok": false, "msg": "Song too short (min 10 sec)."}
	var id := "s%x%x" % [int(Time.get_unix_time_from_system()), randi() % 0xFFFFF]
	var nm := guess_name(path, bytes)
	if nm == "":
		nm = "Song %d" % (library.size() + 1)
	var f := FileAccess.open(SONGS_DIR + "/" + id + "." + ext, FileAccess.WRITE)
	if f == null:
		return {"ok": false, "msg": "Storage is full or not writable."}
	f.store_buffer(bytes)
	f.close()
	var has_thumb := false
	var img := cover_image(bytes)
	if img != null:
		img.convert(Image.FORMAT_RGB8)
		has_thumb = img.save_jpg(thumb_path(id), 0.88) == OK
	library.append({"id": id, "name": nm, "ext": ext, "dur": dur, "bytes": bytes.size(),
			"thumb": has_thumb, "added": int(Time.get_unix_time_from_system())})
	stats["songs"] = library.size()
	save_now()
	return {"ok": true, "msg": "Saved: " + nm, "id": id}


func remove_song(id: String) -> void:
	var e := find_song(id)
	if e.is_empty():
		return
	DirAccess.remove_absolute(song_path(e))
	DirAccess.remove_absolute(thumb_path(id))
	library.erase(e)
	sg.erase(id)
	_thumb_cache.erase(id)
	var dir := DirAccess.open(CACHE_DIR)
	if dir != null:
		for fn in dir.get_files():
			if fn.begins_with(id + "_"):
				dir.remove(fn)
	stats["songs"] = library.size()
	save_now()


func thumb_texture(id: String) -> Texture2D:
	if _thumb_cache.has(id):
		return _thumb_cache[id]
	var p := thumb_path(id)
	var tex: Texture2D = null
	if FileAccess.file_exists(p):
		var img := Image.load_from_file(p)
		if img != null and not img.is_empty():
			tex = ImageTexture.create_from_image(img)
	_thumb_cache[id] = tex
	return tex


# ------------------------------------------------------------------ ID3 (judul & sampul)

func _be32(b: PackedByteArray, p: int) -> int:
	return (b[p] << 24) | (b[p + 1] << 16) | (b[p + 2] << 8) | b[p + 3]


func _synchsafe(b: PackedByteArray, p: int) -> int:
	return ((b[p] & 127) << 21) | ((b[p + 1] & 127) << 14) | ((b[p + 2] & 127) << 7) | (b[p + 3] & 127)


func _decode_text(b: PackedByteArray, enc: int) -> String:
	if b.is_empty():
		return ""
	var s := ""
	if enc == 0:
		for v in b:
			if v == 0:
				break
			s += char(v)
	elif enc == 1 or enc == 2:
		var d := b
		var be := enc == 2
		if d.size() >= 2 and d[0] == 0xFF and d[1] == 0xFE:
			d = d.slice(2)
			be = false
		elif d.size() >= 2 and d[0] == 0xFE and d[1] == 0xFF:
			d = d.slice(2)
			be = true
		if be:
			var sw := PackedByteArray()
			sw.resize(d.size() - (d.size() % 2))
			for i in range(0, sw.size(), 2):
				sw[i] = d[i + 1]
				sw[i + 1] = d[i]
			d = sw
		s = d.get_string_from_utf16()
	else:
		s = b.get_string_from_utf8()
	return s.replace(String.chr(0), "").strip_edges()


## Mengembalikan "Artist - Title" / "Title" dari tag ID3v2.3/2.4 (kosong bila tidak ada).
func id3_text(b: PackedByteArray) -> String:
	if b.size() < 20 or not (b[0] == 0x49 and b[1] == 0x44 and b[2] == 0x33):
		return ""
	var ver := int(b[3])
	if ver < 3:
		return ""
	var end := mini(10 + _synchsafe(b, 6), b.size() - 10)
	var p := 10
	var title := ""
	var artist := ""
	while p + 10 < end:
		var fid := String.chr(b[p]) + String.chr(b[p + 1]) + String.chr(b[p + 2]) + String.chr(b[p + 3])
		var fs := _synchsafe(b, p + 4) if ver == 4 else _be32(b, p + 4)
		if fs <= 0 or p + 10 + fs > b.size() or b[p] == 0:
			break
		if fid == "TIT2" or fid == "TPE1":
			var enc := int(b[p + 10])
			var t := _decode_text(b.slice(p + 11, p + 10 + fs), enc)
			if fid == "TIT2":
				title = t
			else:
				artist = t
		p += 10 + fs
	if title == "":
		return ""
	return (artist + " - " + title) if artist != "" else title


func guess_name(path: String, bytes: PackedByteArray) -> String:
	var t := id3_text(bytes)
	if t != "":
		return t.left(60)
	var f := path.uri_decode().get_file().get_basename()
	if f.contains(":") and f.substr(f.find(":") + 1).is_valid_int():
		return ""
	if f == "" or f.is_valid_int():
		return ""
	return f.left(60)


## Ambil sampul (APIC) dari tag ID3v2. Kembalikan Image persegi <=256px atau null.
func cover_image(b: PackedByteArray) -> Image:
	if b.size() < 20 or not (b[0] == 0x49 and b[1] == 0x44 and b[2] == 0x33):
		return null
	var ver := int(b[3])
	if ver < 3:
		return null
	var end := mini(10 + _synchsafe(b, 6), b.size() - 10)
	var p := 10
	while p + 10 < end:
		var fid := String.chr(b[p]) + String.chr(b[p + 1]) + String.chr(b[p + 2]) + String.chr(b[p + 3])
		var fs := _synchsafe(b, p + 4) if ver == 4 else _be32(b, p + 4)
		if fs <= 0 or p + 10 + fs > b.size() or b[p] == 0:
			break
		if fid != "APIC":
			p += 10 + fs
			continue
		if fs > 8 * 1024 * 1024:
			return null
		var q := p + 10
		var fend := p + 10 + fs
		var enc := int(b[q])
		q += 1
		var mime := ""
		while q < fend and b[q] != 0:
			mime += char(b[q])
			q += 1
		q += 2                       # null mime + tipe gambar
		if enc == 1 or enc == 2:
			while q + 1 < fend and not (b[q] == 0 and b[q + 1] == 0):
				q += 2
			q += 2
		else:
			while q < fend and b[q] != 0:
				q += 1
			q += 1
		if fend - q < 100:
			return null
		var pic := b.slice(q, fend)
		var img := Image.new()
		var err := ERR_FILE_UNRECOGNIZED
		if mime.to_lower().contains("png") or (pic[0] == 0x89 and pic[1] == 0x50):
			err = img.load_png_from_buffer(pic)
		else:
			err = img.load_jpg_from_buffer(pic)
		if err != OK or img.is_empty():
			return null
		var s := mini(img.get_width(), img.get_height())
		var cropped := img.get_region(Rect2i((img.get_width() - s) / 2, (img.get_height() - s) / 2, s, s))
		if s > 256:
			cropped.resize(256, 256, Image.INTERPOLATE_BILINEAR)
		return cropped
	return null


# ------------------------------------------------------------------ cache analisis

func cache_path(id: String, tag: String) -> String:
	return CACHE_DIR + "/" + id + "_" + tag + ".bin"


func cache_write(path: String, data: Dictionary) -> void:
	data["ver"] = CACHE_VER
	var f := FileAccess.open(path, FileAccess.WRITE)
	if f == null:
		return
	f.store_var(data)
	f.close()


func cache_read(path: String) -> Variant:
	if not FileAccess.file_exists(path):
		return null
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return null
	var d = f.get_var()
	f.close()
	if d is Dictionary and int(d.get("ver", 0)) == CACHE_VER:
		return d
	return null


func cache_bytes() -> int:
	var total := 0
	var dir := DirAccess.open(CACHE_DIR)
	if dir == null:
		return 0
	for fn in dir.get_files():
		if fn == "bgm.mp3":
			continue
		var f := FileAccess.open(CACHE_DIR + "/" + fn, FileAccess.READ)
		if f != null:
			total += f.get_length()
			f.close()
	return total


func cache_clear() -> void:
	var dir := DirAccess.open(CACHE_DIR)
	if dir == null:
		return
	for fn in dir.get_files():
		if fn != "bgm.mp3":
			dir.remove(fn)


# ------------------------------------------------------------------ skor terbaik, statistik, prestasi

func best_get(id: String, diff: int) -> int:
	return int(best.get(id + ":" + str(diff), 0))


## Simpan jika lebih tinggi. Mengembalikan true bila memecahkan rekor sebelumnya (>0).
func best_try(id: String, diff: int, score: int) -> bool:
	var k := id + ":" + str(diff)
	var old := int(best.get(k, 0))
	if score > old:
		best[k] = score
		save_soon()
		return old > 0
	return false


func grade_best(id: String) -> String:
	var g: Dictionary = sg.get(id, {})
	for i in range(C.GRS.size() - 1, -1, -1):
		if int(g.get(C.GRS[i], 0)) > 0:
			return C.GRS[i]
	return ""


func grade_counts(id: String) -> Dictionary:
	return sg.get(id, {})


## Catat satu permainan selesai. run: {diff, cnt[4], maxC, score, acc, grade, failed, hp, holds, id}
func record_run(run: Dictionary) -> void:
	var cnt: Array = run["cnt"]
	stats["plays"] += 1
	stats["hits"] += int(cnt[0]) + int(cnt[1]) + int(cnt[2])
	stats["perfects"] += int(cnt[2])
	stats["greats"] += int(cnt[1])
	stats["goods"] += int(cnt[0])
	stats["misses"] += int(cnt[3])
	stats["bestCombo"] = maxi(int(stats["bestCombo"]), int(run["maxC"]))
	var g: String = run["grade"]
	stats["grades"][g] = int(stats["grades"].get(g, 0)) + 1
	var id: String = run["id"]
	if not sg.has(id):
		sg[id] = {}
	sg[id][g] = int(sg[id].get(g, 0)) + 1
	var diff: int = run["diff"]
	if not run["failed"]:
		stats["clear"][diff] = 1
		if int(cnt[3]) == 0:
			stats["fc"][diff] = 1
	else:
		stats["fails"] += 1
	stats["maxScore"] = maxi(int(stats["maxScore"]), int(run["score"]))
	stats["bestAcc"] = maxf(float(stats["bestAcc"]), float(run["acc"]))
	stats["holds"] += int(run["holds"])
	var h := int(Time.get_datetime_dict_from_system()["hour"])
	if h >= 22 or h < 4:
		stats["night"] = 1
	if not run["failed"] and float(run["hp"]) < 20.0:
		stats["lowhp"] = 1
	if not stats["diffs"].has(diff):
		stats["diffs"].append(diff)
	save_soon()


func _stat_value(key: String, run: Dictionary) -> float:
	if key.begins_with("g:"):
		return float(int(stats["grades"].get(key.substr(2), 0)))
	if key.begins_with("fc:"):
		return float(stats["fc"][int(key.substr(3))])
	if key.begins_with("cl:"):
		return float(stats["clear"][int(key.substr(3))])
	if key == "diffs":
		return float(stats["diffs"].size())
	if key == "racc":
		return float(run.get("acc", 0.0))
	return float(stats.get(key, 0))


## Periksa prestasi baru. Mengembalikan daftar [nama, deskripsi] yang baru terbuka.
func check_achv(run: Dictionary = {}) -> Array:
	var added: Array = []
	for a in C.ACHV:
		var id: String = a[0]
		if achv.has(id):
			continue
		if _stat_value(String(a[4]), run) >= float(a[5]):
			achv.append(id)
			added.append([a[1], a[2]])
	if not added.is_empty():
		save_soon()
	return added
