extends Control
## HUD (skor, akurasi, HP, kombo, penilaian, hitung mundur). Digambar di resolusi layar penuh agar teks tajam.

signal pause_pressed

const CONSTS = preload("res://scripts/consts.gd")

var g: Node = null
var pause_btn: Button
var _font: Font
var _sb_panel := StyleBoxFlat.new()
var _sb_track := StyleBoxFlat.new()
var _sb_fill := StyleBoxFlat.new()
var _ins_r := 0.0
var _ins_t := 0.0


func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	visible = false
	_sb_panel.bg_color = Color(10.0 / 255.0, 8.0 / 255.0, 28.0 / 255.0, 0.62)
	_sb_panel.border_color = Color(1, 1, 1, 0.12)
	_sb_panel.set_border_width_all(1)
	_sb_panel.anti_aliasing = true


func _ready() -> void:
	_font = get_theme_default_font()
	pause_btn = Button.new()
	pause_btn.icon = load("res://assets/ui/pause.png")
	pause_btn.expand_icon = true
	pause_btn.add_theme_constant_override("icon_max_width", 30)
	pause_btn.custom_minimum_size = Vector2(68, 68)
	pause_btn.focus_mode = Control.FOCUS_NONE
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.039, 0.031, 0.11, 0.7)
	sb.border_color = Color(1, 1, 1, 0.22)
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(34)
	pause_btn.add_theme_stylebox_override("normal", sb)
	pause_btn.add_theme_stylebox_override("hover", sb)
	pause_btn.add_theme_stylebox_override("pressed", sb)
	pause_btn.pressed.connect(func(): pause_pressed.emit())
	add_child(pause_btn)
	pause_btn.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	_place_button()


func set_insets(r: float, t: float) -> void:
	_ins_r = r
	_ins_t = t
	_place_button()


func _place_button() -> void:
	if pause_btn == null:
		return
	pause_btn.anchor_left = 1.0
	pause_btn.anchor_right = 1.0
	pause_btn.anchor_top = 0.0
	pause_btn.anchor_bottom = 0.0
	pause_btn.offset_left = -(84.0 + _ins_r)
	pause_btn.offset_right = -(16.0 + _ins_r)
	pause_btn.offset_top = 14.0 + _ins_t
	pause_btn.offset_bottom = 82.0 + _ins_t


func _t(text: String, x: float, y: float, sz: float, col: Color, align: HorizontalAlignment = HORIZONTAL_ALIGNMENT_LEFT, w: float = -1.0, hs: float = 1.0) -> void:
	draw_string(_font, Vector2(x * hs, y * hs), text, align, w * hs if w > 0.0 else -1.0, maxi(6, int(sz * hs)), col)


func _draw() -> void:
	if g == null or g.state == "idle" or _font == null:
		return
	var hs: float = size.y / 400.0
	var S: float = g.S
	var W: float = g.W
	var H: float = g.H
	var LX: float = g.LX
	var L: float = g.L
	var now: float = g.hold_now
	# progress lagu
	var pr := clampf(now / maxf(1.0, float(g.dur)), 0.0, 1.0)
	draw_rect(Rect2(LX * hs, 0, L * hs, 4.0 * hs), Color(1, 1, 1, 0.12))
	draw_rect(Rect2(LX * hs, 0, L * hs * pr, 4.0 * hs), Color("#ff3d81"))
	# panel skor
	var w := minf(220.0 * S, L * 0.6)
	var x0 := LX + 8.0
	var y0: float = g.sb_top + 8.0 * S
	_sb_panel.set_corner_radius_all(int(16.0 * S * hs))
	draw_style_box(_sb_panel, Rect2(x0 * hs, y0 * hs, w * hs, 66.0 * S * hs))
	_t(CONSTS.fmt_int(roundi(float(g.dsc))), x0 + 12.0 * S, y0 + 29.0 * S, 27.0 * S, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT, -1.0, hs)
	_t("%.1f%%" % (float(g.accuracy()) * 100.0), x0 + w - 12.0 * S - 100.0, y0 + 17.0 * S, 13.0 * S, Color("#b7b1e6"), HORIZONTAL_ALIGNMENT_RIGHT, 100.0, hs)
	# HP
	var hp: float = g.hp
	var hp_g: float = g.hp_g
	var bx := x0 + 32.0 * S
	var bw := w - 46.0 * S
	var bh := 11.0 * S
	var by := y0 + 43.0 * S
	var low := hp < 30.0
	var f := maxf(0.0, hp) / 100.0
	var hb := 1.0 + (0.18 * absf(sin(float(Time.get_ticks_msec()) / 1000.0 * 9.0)) if low else 0.0)
	_heart(Vector2((x0 + 16.0 * S) * hs, (by + bh / 2.0) * hs), 8.0 * S * hs * hb, Color("#ff4d6d") if low else Color("#ff7aa5"))
	_sb_track.bg_color = Color(1, 1, 1, 0.1)
	_sb_track.set_corner_radius_all(int(bh * hs / 2.0))
	draw_style_box(_sb_track, Rect2(bx * hs, by * hs, bw * hs, bh * hs))
	if hp_g > hp + 0.5:
		_sb_fill.bg_color = Color(1, 1, 1, 0.6)
		_sb_fill.set_corner_radius_all(int(bh * hs / 2.0))
		draw_style_box(_sb_fill, Rect2(bx * hs, by * hs, maxf(bh, bw * hp_g / 100.0) * hs, bh * hs))
	if f > 0.0:
		var ca := Color("#ff4d6d") if low else Color("#2ee6a6")
		var cb := Color("#ff9f1c") if low else Color("#3aa0ff")
		var fw := maxf(bh, bw * f)
		var r := Rect2(bx * hs, by * hs, fw * hs, bh * hs)
		var pts := PackedVector2Array([r.position, Vector2(r.end.x, r.position.y), r.end, Vector2(r.position.x, r.end.y)])
		draw_primitive(pts, PackedColorArray([ca, cb.lerp(ca, 1.0 - clampf(fw / bw, 0.0, 1.0)), cb.lerp(ca, 1.0 - clampf(fw / bw, 0.0, 1.0)), ca]), PackedVector2Array())
	for i in range(1, 4):
		draw_line(Vector2((bx + bw * float(i) / 4.0) * hs, by * hs), Vector2((bx + bw * float(i) / 4.0) * hs, (by + bh) * hs), Color(0.04, 0.03, 0.11, 0.55), 1.5)
	# kombo
	var combo: int = g.combo
	if combo >= 2:
		var sz := (46.0 + float(g.cp) * 12.0) * S
		var pos := Vector2(W / 2.0 * hs - 200.0 * hs, H * 0.3 * hs)
		draw_string_outline(_font, pos, str(combo), HORIZONTAL_ALIGNMENT_CENTER, 400.0 * hs, int(sz * hs), int(6.0 * hs), Color(1.0, 0.24, 0.5, 0.45))
		draw_string(_font, pos, str(combo), HORIZONTAL_ALIGNMENT_CENTER, 400.0 * hs, int(sz * hs), Color.WHITE)
		_t("COMBO", W / 2.0 - 100.0, H * 0.3 + 18.0 * S, 12.0 * S, Color("#9e98cc"), HORIZONTAL_ALIGNMENT_CENTER, 200.0, hs)
	# penilaian
	var a := float(Time.get_ticks_msec() - int(g.pop_start)) / 550.0
	if g.pop_text != "" and a < 1.0:
		var pc: Color = g.pop_color
		pc.a = 1.0 - a * a
		var psz := (22.0 + (1.0 - a) * 8.0) * S
		_t(String(g.pop_text), W / 2.0 - 150.0, g.HY - H * 0.16, psz, pc, HORIZONTAL_ALIGNMENT_CENTER, 300.0, hs)
	# hitung mundur
	var big := ""
	if g.state == "count":
		big = String(g.cd_text)
	elif g.state == "play" and int(g.pre_num) > 0:
		big = str(int(g.pre_num))
	elif g.state == "pause":
		big = ""
	if big != "":
		var ph := fposmod(float(Time.get_ticks_msec()) / 650.0, 1.0)
		var col := Color(1, 1, 1, 1.0 - ph * 0.55)
		var bsz := (96.0 - ph * 14.0) * S
		draw_string_outline(_font, Vector2((W / 2.0 - 150.0) * hs, (H * 0.5 + 30.0 * S) * hs), big, HORIZONTAL_ALIGNMENT_CENTER, 300.0 * hs, int(bsz * hs), int(8.0 * hs), Color(1.0, 0.24, 0.5, 0.35 * col.a))
		draw_string(_font, Vector2((W / 2.0 - 150.0) * hs, (H * 0.5 + 30.0 * S) * hs), big, HORIZONTAL_ALIGNMENT_CENTER, 300.0 * hs, int(bsz * hs), col)


func _heart(c: Vector2, r: float, col: Color) -> void:
	var pts := PackedVector2Array()
	for i in 28:
		var t := TAU * float(i) / 28.0
		var x := 16.0 * pow(sin(t), 3.0)
		var y := -(13.0 * cos(t) - 5.0 * cos(2.0 * t) - 2.0 * cos(3.0 * t) - cos(4.0 * t))
		pts.append(c + Vector2(x, y) * (r / 16.0))
	draw_colored_polygon(pts, col)
