extends "res://scripts/s_base.gd"
## Daftar prestasi (54).

const C = preload("res://scripts/consts.gd")

var _list: VBoxContainer
var _sub: Label


func _ready() -> void:
	var col := UI.vbox(14)
	mc.add_child(col)
	var h := header("Achievements", "")
	_sub = (h.get_child(1).get_child(1) as Label)
	col.add_child(h)
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_list = UI.vbox(10)
	_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(_list)
	col.add_child(sc)


func on_enter(_args: Dictionary = {}) -> void:
	UI.clear_children(_list)
	_sub.text = "%d / %d unlocked" % [Store.achv.size(), C.ACHV.size()]
	# yang terbuka di atas
	var order: Array = []
	for a in C.ACHV:
		if Store.achv.has(a[0]):
			order.append(a)
	for a in C.ACHV:
		if not Store.achv.has(a[0]):
			order.append(a)
	for a in order:
		_list.add_child(_row(a, Store.achv.has(a[0])))


func _row(a: Array, got: bool) -> Control:
	var tc := Color(C.TIER_C[int(a[3])])
	var p := UI.panel(Color(0.09, 0.075, 0.2, 0.9) if got else Color(0.05, 0.04, 0.12, 0.7), tc if got else UI.LINE, 18, 14)
	var h := UI.hbox(16)
	p.add_child(h)
	h.add_child(UI.icon_rect("check" if got else "lock", 44, tc if got else Color(1, 1, 1, 0.3)))
	var v := UI.vbox(2)
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_child(UI.label(String(a[1]), 26, UI.TX if got else UI.MUT))
	v.add_child(UI.label(String(a[2]), 19, UI.MUT))
	h.add_child(v)
	var tl := UI.label(String(C.TIER_N[int(a[3])]), 20, tc if got else Color(1, 1, 1, 0.3))
	tl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	h.add_child(tl)
	return p
