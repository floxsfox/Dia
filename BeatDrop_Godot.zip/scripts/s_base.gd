extends Control
## Dasar semua layar UI: latar opsional + margin yang menghormati area aman (notch / gesture bar).

signal nav(target: String, args: Dictionary)
signal toast_req(msg: String)

const UI = preload("res://scripts/ui.gd")

var mc: MarginContainer
var bg: ColorRect
var bg_alpha := 0.0


func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	visible = false
	bg = ColorRect.new()
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bg.color = Color(0.039, 0.031, 0.094, 0.0)
	add_child(bg)
	mc = MarginContainer.new()
	mc.set_anchors_preset(Control.PRESET_FULL_RECT)
	mc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	for k in ["margin_left", "margin_right"]:
		mc.add_theme_constant_override(k, 36)
	for k in ["margin_top", "margin_bottom"]:
		mc.add_theme_constant_override(k, 24)
	add_child(mc)


func set_bg_alpha(a: float) -> void:
	bg_alpha = a
	bg.color = Color(0.039, 0.031, 0.094, a)


func set_insets(l: float, t: float, r: float, b: float) -> void:
	mc.add_theme_constant_override("margin_left", int(l) + 36)
	mc.add_theme_constant_override("margin_right", int(r) + 36)
	mc.add_theme_constant_override("margin_top", int(t) + 24)
	mc.add_theme_constant_override("margin_bottom", int(b) + 24)


## Dipanggil main saat layar ditampilkan.
func on_enter(_args: Dictionary = {}) -> void:
	pass


## Tombol Back Android / ESC.
func on_back() -> void:
	nav.emit("menu", {})


func header(title: String, subtitle: String, back_target: String = "menu") -> HBoxContainer:
	var h := UI.hbox(16)
	var back := UI.icon_button("back", "Back", 24, Vector2(150, 64))
	back.pressed.connect(func():
		Sfx.click()
		nav.emit(back_target, {}))
	h.add_child(back)
	var v := UI.vbox(0)
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	v.add_child(UI.label(title, 38, UI.TX))
	v.add_child(UI.label(subtitle, 20, UI.MUT))
	h.add_child(v)
	return h
