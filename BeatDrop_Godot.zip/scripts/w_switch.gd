extends Control
## Saklar on/off sentuh.

signal toggled(on: bool)

var on := false
var _sb_off := StyleBoxFlat.new()
var _sb_on := StyleBoxFlat.new()


func _init() -> void:
	custom_minimum_size = Vector2(92, 48)
	mouse_filter = Control.MOUSE_FILTER_STOP
	_sb_off.bg_color = Color("#2d2757")
	_sb_on.bg_color = Color("#2ee6a6")
	for sb in [_sb_off, _sb_on]:
		sb.set_corner_radius_all(24)


func set_on(v: bool, emit: bool = false) -> void:
	on = v
	queue_redraw()
	if emit:
		toggled.emit(on)


func _gui_input(e: InputEvent) -> void:
	if e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT and e.pressed:
		set_on(not on, true)
		accept_event()


func _draw() -> void:
	var r := Rect2(Vector2.ZERO, Vector2(minf(size.x, 92.0), 48.0))
	draw_style_box(_sb_on if on else _sb_off, r)
	var kx := r.size.x - 24.0 if on else 24.0
	draw_circle(Vector2(kx, 24.0), 18.0, Color.WHITE)
