extends Control
## Slider sentuh buatan sendiri (lebih besar & jelas di ponsel).

signal value_changed(v: float)

var min_v := 0.0
var max_v := 1.0
var step_v := 0.0
var value := 0.0
var fill_a := Color("#ff3d81")
var fill_b := Color("#7c5cff")

var _drag := false
const PAD := 20.0


func _init() -> void:
	custom_minimum_size = Vector2(120, 48)
	mouse_filter = Control.MOUSE_FILTER_STOP


func setup(mn: float, mx: float, st: float, v: float) -> void:
	min_v = mn
	max_v = mx
	step_v = st
	value = clampf(v, mn, mx)
	queue_redraw()


func set_value_silent(v: float) -> void:
	value = clampf(v, min_v, max_v)
	queue_redraw()


func nudge(delta: float) -> void:
	_apply(value + delta)


func _apply(v: float) -> void:
	var nv := clampf(v, min_v, max_v)
	if step_v > 0.0:
		nv = clampf(snappedf(nv, step_v), min_v, max_v)
	if not is_equal_approx(nv, value):
		value = nv
		queue_redraw()
		value_changed.emit(value)


func _from_x(x: float) -> void:
	var t := clampf((x - PAD) / maxf(1.0, size.x - PAD * 2.0), 0.0, 1.0)
	_apply(min_v + t * (max_v - min_v))


func _gui_input(e: InputEvent) -> void:
	if e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT:
		_drag = e.pressed
		if e.pressed:
			_from_x(e.position.x)
		accept_event()
	elif e is InputEventMouseMotion and _drag:
		_from_x(e.position.x)
		accept_event()


func _draw() -> void:
	var cy := size.y * 0.5
	var tw := maxf(1.0, size.x - PAD * 2.0)
	var t := 0.0 if max_v <= min_v else (value - min_v) / (max_v - min_v)
	draw_line(Vector2(PAD, cy), Vector2(PAD + tw, cy), Color(1, 1, 1, 0.12), 10.0)
	if t > 0.0:
		draw_line(Vector2(PAD, cy), Vector2(PAD + tw * t, cy), fill_a.lerp(fill_b, t), 10.0)
	var kp := Vector2(PAD + tw * t, cy)
	draw_circle(kp, 17.0, Color(0, 0, 0, 0.35))
	draw_circle(kp, 15.0, Color.WHITE)
	draw_circle(kp, 8.0, fill_a.lerp(fill_b, t))
