extends "res://scripts/s_base.gd"
## Intro: animasi logo (atau video res://assets/intro.ogv bila ada). Ketuk untuk melewati.

const VIDEO_PATH := "res://assets/intro.ogv"
const LOGO_SHADER := """
shader_type canvas_item;
void fragment() {
	float h = fract(UV.x * 0.6 + TIME * 0.12);
	vec3 k = clamp(abs(fract(vec3(h) + vec3(1.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0) - 1.0, 0.0, 1.0);
	COLOR = vec4(mix(vec3(1.0), k, 0.7), COLOR.a);
}
"""

var _done := false
var _video: VideoStreamPlayer = null
var _logo: Control


func _ready() -> void:
	set_bg_alpha(1.0)
	var col := UI.vbox(10)
	col.alignment = BoxContainer.ALIGNMENT_CENTER
	mc.add_child(col)
	var row := UI.hbox(0)
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	var a := UI.label("Beat", 120, UI.TX)
	var b := UI.label("Drop", 120, Color.WHITE)
	var sh := Shader.new()
	sh.code = LOGO_SHADER
	var m := ShaderMaterial.new()
	m.shader = sh
	b.material = m
	row.add_child(a)
	row.add_child(b)
	col.add_child(row)
	col.add_child(UI.label("Turn any song into a rhythm game", 26, UI.MUT, HORIZONTAL_ALIGNMENT_CENTER))
	col.add_child(UI.spacer(40))
	col.add_child(UI.label("Tap to start", 20, Color(1, 1, 1, 0.45), HORIZONTAL_ALIGNMENT_CENTER))
	_logo = col


func on_enter(_args: Dictionary = {}) -> void:
	_done = false
	if ResourceLoader.exists(VIDEO_PATH):
		var vs = load(VIDEO_PATH)
		if vs is VideoStream:
			_video = VideoStreamPlayer.new()
			_video.stream = vs
			_video.set_anchors_preset(Control.PRESET_FULL_RECT)
			_video.expand = true
			_video.finished.connect(_finish)
			add_child(_video)
			_video.play()
			_logo.visible = false
			return
	_logo.modulate.a = 0.0
	_logo.scale = Vector2(0.9, 0.9)
	_logo.pivot_offset = _logo.size / 2.0
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(_logo, "modulate:a", 1.0, 0.7)
	tw.tween_property(_logo, "scale", Vector2.ONE, 0.9).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.chain().tween_interval(1.4)
	tw.chain().tween_callback(_finish)
	Sfx.play("unlock")


func _finish() -> void:
	if _done:
		return
	_done = true
	nav.emit("menu", {})


func _gui_input(e: InputEvent) -> void:
	if e is InputEventMouseButton and e.pressed:
		_finish()


func on_back() -> void:
	_finish()
