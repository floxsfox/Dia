extends "res://scripts/s_base.gd"
## Menu jeda.


func _ready() -> void:
	set_bg_alpha(0.8)
	var col := UI.vbox(16)
	col.alignment = BoxContainer.ALIGNMENT_CENTER
	mc.add_child(col)
	col.add_child(UI.label("Paused", 56, UI.TX, HORIZONTAL_ALIGNMENT_CENTER))
	col.add_child(UI.spacer(8))
	var c := CenterContainer.new()
	var v := UI.vbox(14)
	c.add_child(v)
	col.add_child(c)
	var rs := UI.primary_button("Resume", 30, Vector2(380, 76))
	rs.pressed.connect(func():
		Sfx.click()
		nav.emit("resume", {}))
	v.add_child(rs)
	var rt := UI.button("Retry", 26, Vector2(380, 66))
	rt.pressed.connect(func():
		Sfx.click()
		nav.emit("retry", {}))
	v.add_child(rt)
	var mn := UI.button("Quit to menu", 26, Vector2(380, 66))
	mn.pressed.connect(func():
		Sfx.click()
		nav.emit("menu", {}))
	v.add_child(mn)


func on_back() -> void:
	nav.emit("resume", {})
