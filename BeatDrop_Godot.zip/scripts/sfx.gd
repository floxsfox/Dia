extends Node
## Efek suara (disintesis di kode, tanpa file), musik menu (online + cache offline), dan bus audio.

const SR := 22050
const BGM_URL := "https://user.uploads.dev/file/96ac634348fd57e36f48bf33fa197d36.mp3"
const BGM_BUNDLED := "res://assets/audio/bgm_menu.mp3"   # opsional: taruh mp3 di sini agar selalu ada offline
const BGM_REFRESH_SEC := 14 * 86400

var bgm: AudioStreamPlayer
var music_bus_name := "Music"
var spectrum: AudioEffectSpectrumAnalyzerInstance = null

var _streams := {}
var _pool: Array = []
var _pool_i := 0
var _http: HTTPRequest
var _downloading := false
var _bgm_wanted := false
var _bgm_path := ""


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_setup_buses()
	for i in 8:
		var p := AudioStreamPlayer.new()
		p.bus = "Master"
		add_child(p)
		_pool.append(p)
	bgm = AudioStreamPlayer.new()
	bgm.bus = music_bus_name
	bgm.volume_db = linear_to_db(0.35)
	add_child(bgm)
	_bgm_path = Store.CACHE_DIR + "/bgm.mp3"
	_http = HTTPRequest.new()
	_http.timeout = 25.0
	_http.use_threads = true
	add_child(_http)
	_http.request_completed.connect(_on_bgm_downloaded)
	_build_sounds()


func _setup_buses() -> void:
	if AudioServer.get_bus_index(music_bus_name) != -1:
		return
	AudioServer.add_bus()
	var idx := AudioServer.bus_count - 1
	AudioServer.set_bus_name(idx, music_bus_name)
	AudioServer.set_bus_send(idx, "Master")
	var fx := AudioEffectSpectrumAnalyzer.new()
	AudioServer.add_bus_effect(idx, fx)
	spectrum = AudioServer.get_bus_effect_instance(idx, 0) as AudioEffectSpectrumAnalyzerInstance


## Tingkat bass 0..1 untuk denyut latar (pengganti AnalyserNode di versi web).
func bass_level() -> float:
	if spectrum == null:
		return 0.0
	var m: Vector2 = spectrum.get_magnitude_for_frequency_range(30.0, 220.0)
	var e := (m.x + m.y) * 0.5
	var db := linear_to_db(maxf(e, 0.000001))
	return clampf((db + 48.0) / 40.0, 0.0, 1.0)


# ------------------------------------------------------------------ sintesis efek

func _tone(f0: float, f1: float, dur: float, kind: String, vol: float) -> PackedFloat32Array:
	var n := int(dur * SR) + 1
	var out := PackedFloat32Array()
	out.resize(n)
	var lf0 := log(maxf(30.0, f0))
	var lf1 := log(maxf(30.0, f1))
	var phase := 0.0
	var decay_len := maxf(0.001, dur - 0.008)
	for i in n:
		var t := float(i) / float(SR)
		var f := exp(lf0 + (lf1 - lf0) * (t / dur))
		phase += f / float(SR)
		var ph := phase - floorf(phase)
		var s := 0.0
		match kind:
			"sine":
				s = sin(ph * TAU)
			"triangle":
				s = 4.0 * absf(ph - 0.5) - 1.0
			"square":
				s = 1.0 if ph < 0.5 else -1.0
			_:
				s = 2.0 * ph - 1.0
		var g := 0.0
		if t < 0.008:
			g = vol * t / 0.008
		else:
			g = vol * pow(0.0001 / vol, (t - 0.008) / decay_len)
		out[i] = s * g
	return out


func _mix_into(dst: PackedFloat32Array, src: PackedFloat32Array, delay: float) -> PackedFloat32Array:
	var off := int(delay * SR)
	var need := off + src.size()
	if dst.size() < need:
		dst.resize(need)
	for i in src.size():
		dst[off + i] += src[i]
	return dst


func _to_stream(samples: PackedFloat32Array) -> AudioStreamWAV:
	var bytes := PackedByteArray()
	bytes.resize(samples.size() * 2)
	for i in samples.size():
		var v := clampi(int(samples[i] * 32767.0), -32768, 32767)
		bytes.encode_s16(i * 2, v)
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = SR
	w.stereo = false
	w.data = bytes
	return w


func _make(parts: Array) -> AudioStreamWAV:
	# parts: [[f0, f1, dur, kind, vol, delay], ...]
	var mix := PackedFloat32Array()
	for p in parts:
		mix = _mix_into(mix, _tone(p[0], p[1], p[2], p[3], p[4]), p[5])
	return _to_stream(mix)


func _build_sounds() -> void:
	_streams["click"] = _make([[660.0, 990.0, 0.07, "triangle", 0.12, 0.0]])
	_streams["hit2"] = _make([[880.0, 1320.0, 0.09, "sine", 0.14, 0.0], [1760.0, 1760.0, 0.06, "sine", 0.06, 0.03]])
	_streams["hit1"] = _make([[740.0, 1108.0, 0.08, "sine", 0.11, 0.0]])
	_streams["hit0"] = _make([[520.0, 520.0, 0.06, "sine", 0.08, 0.0]])
	_streams["miss"] = _make([[170.0, 85.0, 0.2, "sawtooth", 0.16, 0.0]])
	_streams["count"] = _make([[440.0, 440.0, 0.09, "square", 0.08, 0.0]])
	_streams["go"] = _make([[880.0, 880.0, 0.16, "square", 0.1, 0.0], [1320.0, 1320.0, 0.22, "square", 0.08, 0.1]])
	var fan: Array = []
	var fr := [523.0, 659.0, 784.0, 1046.0]
	for i in fr.size():
		fan.append([fr[i], fr[i], 0.16, "triangle", 0.12, i * 0.11])
	_streams["fanfare"] = _make(fan)
	var unl: Array = []
	var ur := [784.0, 988.0, 1175.0, 1568.0, 1976.0]
	for i in ur.size():
		unl.append([ur[i], ur[i], 0.2, "sine", 0.12, i * 0.09])
	_streams["unlock"] = _make(unl)


func play(sound: String) -> void:
	var s = _streams.get(sound)
	if s == null:
		return
	var p: AudioStreamPlayer = _pool[_pool_i]
	_pool_i = (_pool_i + 1) % _pool.size()
	p.stream = s
	p.play()


func click() -> void:
	play("click")


func hit(q: int) -> void:
	play("hit" + str(clampi(q, 0, 2)))


# ------------------------------------------------------------------ musik menu

func _load_bgm_stream() -> bool:
	var bytes := PackedByteArray()
	if FileAccess.file_exists(_bgm_path):
		bytes = FileAccess.get_file_as_bytes(_bgm_path)
	if bytes.size() < 20000 and ResourceLoader.exists(BGM_BUNDLED):
		var res = load(BGM_BUNDLED)
		if res is AudioStream:
			if res is AudioStreamMP3:
				res.loop = true
			bgm.stream = res
			return true
	if bytes.size() < 20000:
		return false
	var s := AudioStreamMP3.new()
	s.data = bytes
	s.loop = true
	if s.get_length() <= 0.0:
		return false
	bgm.stream = s
	return true


func bgm_start() -> void:
	_bgm_wanted = true
	if bgm.stream == null:
		_load_bgm_stream()
	if bgm.stream != null and not bgm.playing:
		bgm.play()
	_maybe_download()


func bgm_stop() -> void:
	_bgm_wanted = false
	bgm.stop()


func bgm_resume_if_wanted() -> void:
	if _bgm_wanted and bgm.stream != null and not bgm.playing:
		bgm.play()


func _maybe_download() -> void:
	if _downloading:
		return
	if FileAccess.file_exists(_bgm_path):
		var age := Time.get_unix_time_from_system() - float(FileAccess.get_modified_time(_bgm_path))
		if age < BGM_REFRESH_SEC:
			return
	_downloading = true
	_http.download_file = _bgm_path + ".tmp"
	var err := _http.request(BGM_URL)
	if err != OK:
		_downloading = false


func _on_bgm_downloaded(result: int, code: int, _headers: PackedStringArray, _body: PackedByteArray) -> void:
	_downloading = false
	var tmp := _bgm_path + ".tmp"
	var good := false
	if result == HTTPRequest.RESULT_SUCCESS and code == 200 and FileAccess.file_exists(tmp):
		var f := FileAccess.open(tmp, FileAccess.READ)
		if f != null:
			good = f.get_length() > 20000
			f.close()
	if good:
		DirAccess.rename_absolute(tmp, _bgm_path)
		if _load_bgm_stream() and _bgm_wanted and not bgm.playing:
			bgm.play()
	elif FileAccess.file_exists(tmp):
		DirAccess.remove_absolute(tmp)
